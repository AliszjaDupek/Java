public class Uczen extends Osoba {
    protected double srednia;
    protected String klasa;

    public Uczen(){
        imie="Jan";
        nazwisko="Kowalski";
        srednia=4.5;
        klasa="1E";
    }

    @Override
    public String toString() {
        return "Uczen{" +
                "srednia=" + srednia +
                ", klasa='" + klasa + '\'' +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }
}
