public class Dyrektor extends Osoba{

    protected int pensja;
    protected String stanowisko;

    public Dyrektor(){
        imie="Jan";
        nazwisko="Kowalski";
        pensja=6000;
        stanowisko="Dyrektorka";
    }

    @Override
    public String toString() {
        return "Dyrektor{" +
                "pensja=" + pensja +
                ", stanowisko='" + stanowisko + '\'' +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }
}
