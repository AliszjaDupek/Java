public class Main {
    public static void main(String[] args) {
        Osoba o1= new Osoba();
        Osoba o2 = new Osoba();
        Uczen u1 = new Uczen();
        Uczen u2 = new Uczen();
        Nauczyciel n1 = new Nauczyciel();
        Nauczyciel n2 = new Nauczyciel();
        Dyrektor d1 = new Dyrektor();
        Dyrektor d2 = new Dyrektor();

        Szkola szkola = new Szkola();
        szkola.dodajOsobe(o1);
        szkola.dodajOsobe(o2);
        szkola.dodajOsobe(u1);
        szkola.dodajOsobe(u2);
        szkola.dodajOsobe(n1);
        szkola.dodajOsobe(n2);
        szkola.dodajOsobe(d1);
        szkola.dodajOsobe(d2);

        szkola.wyswietlWszystkich();
        System.out.println("----------------");
        System.out.println(szkola.podajDlugosc());
        System.out.println("----------------");
        szkola.wyswietlUczniow();
        System.out.println("----------------");
        szkola.usunOsobe(2);
        szkola.wyswietlWszystkich();
        System.out.println("----------------");
        szkola.wyswietlUczniow();
        System.out.println("----------------");
        System.out.println(szkola.podajDlugosc());
        System.out.println("----------------");
        szkola.wyswietlDyrektorow();
        System.out.println("----------------");
        szkola.wyswietlNauczycieli();
        System.out.println("----------------");
        szkola.wyswietlPracownikow();

    }
}