public class Nauczyciel extends Osoba{
    protected int pensja;
    protected String przedmiot;

    public Nauczyciel(){
        imie="Piotr";
        nazwisko="Kowalski";
        pensja=4000;
        przedmiot="Matematyka";
    }

    @Override
    public String toString() {
        return "Nauczyciel{" +
                "pensja=" + pensja +
                ", przedmiot='" + przedmiot + '\'' +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }
}
