public class Szkola {
    private Osoba[] szkola;
    private int index;

    public Szkola(){
        index=0;
        szkola= new Osoba[8];
    }
    public void dodajOsobe(Osoba osoba){
        if(index< szkola.length) {
            szkola[index] = osoba;
            System.out.println("Dodano osobe, index : "+ index);
            index++;
        }
    }
    public void usunOsobe(int index){
        if(index>0 && index< szkola.length){
            szkola[index]=null;
        }
    }
    public int podajDlugosc(){
        int j=0;
        for(int i=0; i< szkola.length; i++){
            if(szkola[i]!=null){
                j++;
            }
        }
        return j;
    }

    public void wyswietlWszystkich(){
        for(int i=0; i< szkola.length; i++) {
            if (szkola[i] != null) {
                System.out.println(szkola[i].toString());
            }
        }
    }

    public void wyswietlPracownikow(){
        for(int i=0; i< szkola.length; i++){
            if(szkola[i] instanceof Dyrektor || szkola[i] instanceof Nauczyciel){
                System.out.println(szkola[i].toString());
            }
        }
    }

    public void wyswietlUczniow(){
        for(int i=0; i< szkola.length; i++){
            if(szkola[i] instanceof Uczen){
                System.out.println(szkola[i].toString());
            }
        }
    }
    public void wyswietlNauczycieli(){
        for(int i=0; i< szkola.length; i++){
            if(szkola[i] instanceof Nauczyciel){
                System.out.println(szkola[i].toString());
            }
        }
    }
    public void wyswietlDyrektorow(){
        for(int i=0; i< szkola.length; i++){
            if(szkola[i] instanceof Dyrektor){
                System.out.println(szkola[i].toString());
            }
        }
    }
}
