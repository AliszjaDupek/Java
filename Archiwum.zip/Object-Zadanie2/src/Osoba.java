public class Osoba {
    protected String imie;
    protected String nazwisko;

    public Osoba(){
        imie="Jan";
        nazwisko="Kowalski";
    }


    @Override
    public String toString() {
        return "Osoba{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }
}
