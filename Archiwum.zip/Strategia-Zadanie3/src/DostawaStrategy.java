public interface DostawaStrategy {
    void dostawa(String dostawa);
}
