import java.util.Scanner;

public class Paczkomat implements DostawaStrategy{
    protected String[] paczkomaty = new String[6];

    @Override
    public void dostawa(String paczkomat) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Dostawa do paczkomatu, wybierz paczkomat(1 = ul. Jana Krasickiego, 2 = ul. Niepodleglosci)");
        int odp = scanner.nextInt();
        switch (odp){
            case(1):
                System.out.println("Paczkomat na ulicy Jana Krasickiego");
                break;
            case(2):
                System.out.println("Paczkomat na ulicy Niepodleglosci");
                break;
        }


    }
}
