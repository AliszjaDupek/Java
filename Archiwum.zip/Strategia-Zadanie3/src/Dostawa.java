public class Dostawa {
    protected String dostawa;

    private DostawaStrategy strategy;

    public Dostawa(){
        dostawa="kurier";
    }

    public Dostawa(String dostawa){
        this.dostawa=dostawa;
    }

    public void setStrategy(DostawaStrategy strategy){
        this.strategy=strategy;
    }


    public void dostawa() {
        strategy.dostawa(dostawa);
    }
}
