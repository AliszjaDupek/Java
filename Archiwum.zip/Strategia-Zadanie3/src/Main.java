import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Dostawa dostawa = new Dostawa();
        System.out.println("Wybierz sposob dostawy(1 = Paczkomat, 2 = kurier)");
        int wybor = scanner.nextInt();
        switch (wybor){
            case (1):
                dostawa.setStrategy(new Paczkomat());
                dostawa.dostawa();
                break;
            case (2):
                dostawa.setStrategy(new Kurier());
                dostawa.dostawa();
                break;
            default:
                System.out.println("Nie wybrales metody dostawy");
                break;
        }
    }
}