import java.util.Scanner;

public class Kurier implements DostawaStrategy{
    private String adres;

    @Override
    public void dostawa(String adres) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj adres");
        adres=scanner.next();
        System.out.println("Adres = "+adres);
    }
}
