import java.io.*;

public class Deserializacja {
    public static void main(String[]args){
        Prostokat prostokat1 = null;
        Prostokat prostokat2 = null;
        try{
            FileInputStream stream = new FileInputStream("obiekty.ser");
            ObjectInputStream os = new ObjectInputStream(stream);

            Object ob1 = os.readObject();
            Object ob2 = os.readObject();

            prostokat1 = (Prostokat) ob1;
            prostokat2 = (Prostokat) ob2;


            os.close();
        }
        catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
        prostokat1.wyswietl();
        prostokat2.wyswietl();
    }
}
