public class WartoscUjemnaException extends Exception {
    public WartoscUjemnaException(String message){
        super(message);
    }
}
