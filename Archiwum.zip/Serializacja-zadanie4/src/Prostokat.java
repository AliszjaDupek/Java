import java.io.Serializable;

public class Prostokat implements Serializable {
    protected int x;
    protected int y;

    public Prostokat(){
        x=2;
        y=3;
    }
    public Prostokat(int x, int y) throws WartoscUjemnaException {
        if(x<1){
           throw new WartoscUjemnaException("Musisz podac dodatnia wartosc");
        }
        if(y<1){
            throw new WartoscUjemnaException("Musisz podac dodatnia wartosc");
        }
        this.x=x;
        this.y=y;
    }


    public void wyswietl() {
        for(int i=0; i<y;i++){
            for(int j=0; j<x; j++ ){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
