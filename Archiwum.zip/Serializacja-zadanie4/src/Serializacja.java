import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serializacja {
    public static void main(String[] args) throws WartoscUjemnaException {
        Prostokat p1 = new Prostokat();
        Prostokat p2 = new Prostokat(5, 10);

        p1.wyswietl();
        p2.wyswietl();

        File file = new File("obiekty.ser");
        try {
            FileOutputStream stream = new FileOutputStream(file);
            ObjectOutputStream so = new ObjectOutputStream(stream);

            so.writeObject(p1);
            so.writeObject(p2);
            so.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
