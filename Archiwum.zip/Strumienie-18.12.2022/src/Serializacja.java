import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serializacja {
    public static void main(String[]args){
        Postac elf = new Postac("elf",5,6,4);
        Postac troll = new Postac("troll", 9, 2,8);
        Postac wilkolak = new Postac("wilkolak",9,1,6);

        System.out.println(elf.toString());
        System.out.println(troll.toString());
        System.out.println(wilkolak.toString());

        File file = new File("obiekty.ser");
        try{
            FileOutputStream stream = new FileOutputStream(file);
            ObjectOutputStream so = new ObjectOutputStream(stream);

            so.writeObject(elf);
            so.writeObject(troll);
            so.writeObject(wilkolak);
            so.close();
        }catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
}
