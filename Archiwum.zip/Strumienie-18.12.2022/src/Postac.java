import java.io.Serializable;

public class Postac implements Serializable {
    private String rasa;
    private int witalnosc;
    private Moc moc;
    private int magia;
    transient private int sila;

    public Postac(){
        rasa="gnom";
        witalnosc=2;
        sila=3;
        magia=1;
        moc=new Moc();
    }
    public Postac(String rasa, int witalnosc, int magia, int sila){
        this.magia=magia;
        this.rasa=rasa;
        this.witalnosc=witalnosc;
        this.sila=sila;
        moc = new Moc(100);
    }
    public void setWitalnosc(int witalnosc) {
        this.witalnosc = witalnosc;
    }
    public void setSila(int sila) {
        this.sila = sila;
    }
    public int getWitalnosc() {
        return witalnosc;
    }
    public int getSila() {
        return sila;
    }
    public int getMagia() {
        return magia;
    }
    public String getRasa() {
        return rasa;
    }
    public void setMagia(int magia) {
        this.magia = magia;
    }
    public void setRasa(String rasa) {
        this.rasa = rasa;
    }

    @Override
    public String toString() {
        return "Postac{" +
                "rasa='" + rasa + '\'' +
                ", witalnosc=" + witalnosc +
                ", magia=" + magia +
                ", sila=" + sila + ", moc=" + moc.getWartosc() +
                '}';
    }
}
