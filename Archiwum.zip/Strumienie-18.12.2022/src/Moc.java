import java.io.Serializable;

public class Moc implements Serializable {
    protected int wartosc;

    public Moc(){
        wartosc=-1;
    }
    public Moc(int moc){
        wartosc=moc;
    }
    public int getWartosc(){
        return wartosc;
    }
    public void setWartosc(int wartosc){
        this.wartosc=wartosc;
    }


}
