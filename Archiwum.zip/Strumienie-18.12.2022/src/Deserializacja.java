import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.ParsePosition;


public class Deserializacja {
    public static void main(String[]args){
        try{
            FileInputStream stream = new FileInputStream("obiekty.ser");
            ObjectInputStream os = new ObjectInputStream(stream);

            Object ob1 = os.readObject();
            Object ob2 = os.readObject();
            Object ob3 = os.readObject();

            //Rzutowanie
            Postac p1 = (Postac) ob1;
            Postac p2 = (Postac) ob2;
            Postac p3 = (Postac) ob3;
            System.out.println(p1);
            System.out.println(p2);
            System.out.println(p3);

            os.close();
        }
        catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
    }

}
