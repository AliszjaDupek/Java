import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class OdczytPliku {
    public static void main(String[]args){
        File file = new File("plik.txt");
        try {
            FileReader reader = new FileReader(file);
            BufferedReader buffer = new BufferedReader(reader);

            String wiersz = "";
            while((wiersz = buffer.readLine()) != null){
                String [] wszystkoWlinijce = wiersz.split("||");
                for(String slowo: wszystkoWlinijce){
                    System.out.println(slowo);
                }
            }

        buffer.close();
        }catch(IOException e){
            System.out.println(e.getMessage());
        }

    }
}
