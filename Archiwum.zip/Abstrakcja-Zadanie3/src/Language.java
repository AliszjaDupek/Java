public interface Language {
    String sayGreeting();
    String sayGoodbye();
    String sayThanks();
}
