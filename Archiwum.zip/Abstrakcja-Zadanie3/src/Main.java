public class Main {
    public static void main(String[] args) {
        Polish p = new Polish();
        System.out.println(p.sayGreeting());
        Spanish s = new Spanish();
        System.out.println(s.sayGoodbye());
        English e = new English();
        System.out.println(e.sayThanks());
    }
}