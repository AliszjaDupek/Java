public class Polish implements Language{

    @Override
    public String sayGreeting() {
        return "Cześć";
    }

    @Override
    public String sayGoodbye() {
        return "Pa";
    }

    @Override
    public String sayThanks() {
        return "Dziękuję";
    }
}
