public class Mieszkaniec {
    private String imie;
    private String nazwisko;
    //konstruktor d
    public Mieszkaniec(){
        imie = "Jan";
        nazwisko = "Kowalski";
    }
    //konstruktor p
    public Mieszkaniec(String imie, String nazwisko){
        this.imie=imie;
        this.nazwisko=nazwisko;
    }
    //get
    public String getNazwisko() {
        return nazwisko;
    }
    public String getImie() {
        return imie;
    }
    //set
    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    public String toString(){
        return imie+" "+nazwisko;
    }
}
