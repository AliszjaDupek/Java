public class Main {
    public static void main(String[] args) {
//      Ksiazka k1 = new Ksiazka();
//      System.out.println(k1.getAutor());
//      k1.setAutor("Słowacki");
//      System.out.println(k1.getAutor());
//      k1.ustawCene(39.20);
//      System.out.println(k1.toString());
//    Data data1 = new Data();
//    Data data2 = new Data(5,12,2032);
//    data1.wyswietl();
//    data2.wyswietl();
//    data2.ustawDate(data1,32,12,2020);
//    data2.wyswietl();
//    System.out.println(data1.czyRokPrzestepny());
//    System.out.println(data2.czyRokPrzestepny());
//    System.out.println(data1.ileDniMaMiesiac());
//    System.out.println(data2.ileDniMaMiesiac());
//    System.out.println(data1.compareDate(data1, data2));
    Mieszkaniec mieszkaniec1 = new Mieszkaniec();
    Mieszkaniec mieszkaniec2 = new Mieszkaniec("Alicja", "Dudek");
    Mieszkaniec mieszkaniec3 = new Mieszkaniec("Marta", "Dudek");
    mieszkaniec3.setNazwisko("Kowalska");
    System.out.println("Mieszkaniec 1: "+mieszkaniec1.toString());
    System.out.println("Mieszkaniec 2: "+mieszkaniec2.toString());
    Dom dom1 = new Dom();
    Mieszkaniec[] mieszkancy = new Mieszkaniec[2];
    mieszkancy[0]=mieszkaniec1;
    mieszkancy[1]=mieszkaniec2;
    Dom dom2 = new Dom("Owocowa", "Gronowo",7,"64-100", mieszkancy);
    System.out.println("DOM 2-------------");
    System.out.println(dom2.toString());
    System.out.println("------------");
    dom2.wyswietlMieszkancow();
    dom2.dodajMieszkanca(mieszkaniec3,1);
    System.out.println("------------");
    dom2.wyswietlMieszkancow();
    System.out.println("DOM 1-------------");
    System.out.println(dom1.toString());


    }
}











