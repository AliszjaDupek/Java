public class Data {
    private int dzien;
    private int miesiac;
    private int rok;

    //KONSTRUKTOTY:
    public Data() {
        dzien = 5;
        miesiac = 11;
        rok = 2022;
    }
    public Data(int dzien, int miesiac, int rok){
        this.dzien=dzien;
        this.miesiac=miesiac;
        this.rok=rok;
    }
    //GET
    public int getRok() {
        return rok;
    }

    public int getMiesiac() {
        return miesiac;
    }

    public int getDzien() {
        return dzien;
    }

    //SET
    public void setDzien(int dzien) {
        this.dzien = dzien;
    }

    public void setMiesiac(int miesiac) {
        this.miesiac = miesiac;
    }

    public void setRok(int rok) {
        this.rok = rok;
    }

    //METODA WYSWIETL:
    public void wyswietl() {
        System.out.println(dzien + "." + miesiac + "." + rok);
    }

    //METODA USTAW DATE:
    public void ustawDate(Data data, int dzien, int miesiac, int rok) {
        if (miesiac<=12 && miesiac>0 && dzien==data.ileDniMaMiesiac()) {
            this.dzien = dzien;
            this.miesiac = miesiac;
            this.rok = rok;
        }
        else{
                System.out.println("Podaj inna date ");
            }

    }

    public boolean czyRokPrzestepny() {
        if ((rok % 4 == 0 && rok % 100 != 0) || rok % 400 == 0) {
            return true;
        }
        return false;
    }

    //METODA ILE DNI MA MIESIAC
    public int ileDniMaMiesiac() {
        switch (miesiac) {
            case 1:
                return 31;
            case 2:
                if (czyRokPrzestepny() == true) {
                    return 29;
                } else {
                    return 28;
                }
            case 3:
                return 31;
            case 4:
                return 30;
            case 5:
                return 31;
            case 6:
                return 30;
            case 7:
                return 31;
            case 8:
                return 31;
            case 9:
                return 30;
            case 10:
                return 31;
            case 11:
                return 30;
            case 12:
                return 31;
        }
        return 0;
    }

    //METODA COMPAREDATE:
    public int compareDate(Data data1, Data data2) {
        if (data1 == data2) {
            return 0;
        }
        if ((data1.getRok() < data2.getRok()) || (data1.rok==data2.rok && data1.getMiesiac() < data2.getMiesiac()) || (data1.rok==data2.rok && data1.miesiac==data2.miesiac && data1.dzien<data2.dzien)) {
            return -1;
        }
        if ((data1.getRok() > data2.getRok()) || (data1.rok==data2.rok && data1.getMiesiac() > data2.getMiesiac()) || (data1.rok==data2.rok && data1.miesiac==data2.miesiac && data1.dzien>data2.dzien)) {
            return 1;
        }
        return 0;
    }
}