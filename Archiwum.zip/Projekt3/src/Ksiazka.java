public class Ksiazka {
    private String autor;
    private String tytul;
    private double cena;
    public Ksiazka(){
        autor = "Mickiewicz";
        tytul = "Dziady";
        cena = 15.50;
    }
    //Settery/gettery
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public void setTytul(String tytul) {
        this.tytul = tytul;
    }

    public Ksiazka(String autor, String tytul, double cena){
        this.tytul=tytul;
        this.autor=autor;
        this.cena=cena;
    }
    public String getAutor() {
        return autor;
    }
    public String getTytul() {
        return tytul;
    }
    public void ustawCene(double cena){
        if(czyCenaPrawidlowa(cena)==true){
            this.cena=cena;
        }
        else{
            System.out.println("Nie prawidłowa cena");
        }
    }
    private boolean czyCenaPrawidlowa(double cena){
        if (cena>0){
            return true;
        }
        return false;
    }

    public String toString(){
        return (autor+" "+tytul+" "+cena);
    }

}

