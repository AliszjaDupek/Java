public class Dom {
    private String ulica;
    private String miasto;
    private int nrDomu;
    private String kodpocztowy;
    private Mieszkaniec[] mieszkancy;

    public Dom(){
        ulica="Miła";
        miasto="Leszno";
        nrDomu=12;
        kodpocztowy="64-100";
        mieszkancy = new Mieszkaniec[1];
    }
    public Dom(String ulica, String miasto, int nrDomu, String kodpocztowy, Mieszkaniec[] mieszkancy){
        this.ulica=ulica;
        this.miasto=miasto;
        this.nrDomu=nrDomu;
        this.kodpocztowy=kodpocztowy;
        this.mieszkancy=mieszkancy;
    }

    //get
    public String getUlica() {
        return ulica;
    }
    public String getMiasto() {
        return miasto;
    }
    public String getKodpocztowy() {
        return kodpocztowy;
    }
    public int getNrDomu() {
        return nrDomu;
    }
    public Mieszkaniec[] getMieszkancy() {
        return mieszkancy;
    }
    //set
    public void setUlica(String ulica) {
        this.ulica = ulica;
    }
    public void setNrDomu(int nrDomu) {
        this.nrDomu = nrDomu;
    }
    public void setMieszkancy(Mieszkaniec[] mieszkancy) {
        this.mieszkancy = mieszkancy;
    }
    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }
    public void setKodpocztowy(String kodpocztowy) {
        this.kodpocztowy = kodpocztowy;
    }
    //Metody:
    //toString
    public String toString(){
        return "Ulica: "+ulica+"\nMiasto: "+miasto+"\nNumer domu: "+nrDomu+"\nKod pocztowy: "+kodpocztowy;
    }

    //dodaj mieszkanca
    public Mieszkaniec[] dodajMieszkanca(Mieszkaniec mieszkaniec, int index){
        mieszkancy[index]=mieszkaniec;
        return mieszkancy;


    }

    public void wyswietlMieszkancow(){
        for (int i=0; i<mieszkancy.length;i++){
            System.out.println((i+1)+" "+mieszkancy[i]);
        }
    }
}
