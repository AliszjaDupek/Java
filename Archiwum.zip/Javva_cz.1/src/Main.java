import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    /*
        int wiek;
        wiek = 21;
        int liczba = 20;
        boolean czyPelnoletni = false;
        boolean czy_pelnoletni = false;
        char inicjal = 'M';
        double cena = 12.3;
        System.out.println(wiek);
        System.out.println("Mam "+wiek+" lat.");

        final double PI = 3.14;

        int liczba1 = 13;
        int liczba2 = 2;
        int wynik = liczba1%liczba2;
        System.out.println(wynik);
        double dodawanie = (double)liczba1+liczba2;
        System.out.println(dodawanie);

        liczba1 += 4;
        System.out.println(liczba1);
        liczba1 -= 3;
        System.out.println(liczba1);
        liczba1 /= 2;
        System.out.println(liczba1);
        liczba1 *= 2;
        System.out.println(liczba1);
        liczba1 %= 3;
        System.out.println(liczba1);

        liczba1++;
        System.out.println(liczba1);
        liczba1--;
        System.out.println(liczba1);

        String imie = "Alicja";
        System.out.println(imie);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Podaj imie: ");
        String imieUzytkownika = scanner.next();
        System.out.println("Cześć "+imieUzytkownika);
        System.out.println("Podaj wiek: ");
        int wiekUzytkownika = scanner.nextInt();
        System.out.println("Twój wiek: "+wiekUzytkownika);

        int [] tablica = {1,2,3,4,5,6};
        double [] tablica2 = new double[3];
        tablica2[0] = 1.5;
        tablica2[1] = 2.1;
        tablica2[2] = 3.7;
        System.out.println(tablica2[0]);

        String [] tablica3 = {"Jeden", "Dwa", "Trzy"};
        System.out.println(tablica3[0]);
        System.out.println(tablica3[1]);
        System.out.println(tablica3[2]);

        Scanner scanner = new Scanner(System.in);
        int [] tablica4 = new int[3];
        System.out.println("Podaj 3 liczby: ");
        tablica4[0]=scanner.nextInt();
        tablica4[1]=scanner.nextInt();
        tablica4[2]=scanner.nextInt();
        System.out.println(tablica4[0]);
        System.out.println(tablica4[1]);
        System.out.println(tablica4[2]);

        System.out.println("Podaj 2 boki: ");
        int bok1 = scanner.nextInt();
        int bok2 = scanner.nextInt();
        System.out.println("Pole = "+bok1*bok2);
        System.out.println("Obwód = "+((2*bok1)+(2*bok2)));
*/
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Podaj wiek: ");
//        int wiek = scanner.nextInt();
//
//        if (wiek>=18)
//        {
//            System.out.println("Osoba jest pełnoletnia");
//        }
//        else
//        {
//            System.out.println("Osoba nie jest pełnoletnia");
//        }
//        int liczba1 = 10;
//        int liczba2 = 15;
//        if (liczba1>=5 || liczba2<=20)
//        {
//            System.out.println("Prawda");
//        }
//        else
//        {
//            System.out.println("Fałsz");
//        }
//        Scanner scan = new Scanner(System.in);
//        int dzien = scan.nextInt();
//        switch (dzien)
//        {
//            case 1:
//                System.out.println("Poniedziałek");
//                break;
//            case 2:
//                System.out.println("Wtorek");
//                break;
//            case 3:
//                System.out.println("Środa");
//                break;
//            case 4:
//                System.out.println("Czwartek");
//                break;
//            case 5:
//                System.out.println("Piątek");
//                break;
//            case 6:
//                System.out.println("Sobota");
//                break;
//            case 7:
//                System.out.println("Niedziela");
//                break;
//        }
//        int licznik = 26;
//        while (licznik!=0)
//        {
//            System.out.println(licznik);
//            licznik-=5;
//        }
    /*
        double[] tab = {3.4,5.5,10.2,11.2,23.4};
        for(int i=0; i<tab.length ; i++){
            System.out.println(tab[i]);
        }
        for (double liczba: tab){
            System.out.println(liczba);
        }

     */
//        int [] tab = {1,2,3,4,5,6,7,8,9,10};
//        for (int liczba : tab){
//            if (liczba%2==0){
//                System.out.println(liczba);
//            }
//        }
//        Scanner scanner = new Scanner(System.in);
//        String [] tab = {scanner.next(),scanner.next(),scanner.next()};
//        for (int i=2; i>=0; i--){System.out.println(tab[i]);}
        //Zadanie 1
        Scanner scanner = new Scanner(System.in);
        int [] tab = new int[10];
        for(int i=0; i<10; i++){
            tab[i]=scanner.nextInt();
        }
        int najwieksza = 0;
        for (int liczba : tab){
            if (liczba>najwieksza){
                najwieksza=liczba;
            }
        }
        System.out.println(najwieksza);

        //Zadanie 2
        System.out.println("Podaj 2 liczby ");
        float liczba1 = scanner.nextInt();
        float liczba2 = scanner.nextInt();
        System.out.println("Iloczyn=1/suma=2/różnica=3/iloraz=4");
        int operacja = scanner.nextInt();
        switch(operacja) {
            case 1:
                System.out.println("Iloczyn liczb = " + liczba1 * liczba2);
                break;
            case 2:
                System.out.println("Suma liczb = " + (liczba1 + liczba2));
                break;
            case 3:
                System.out.println("Różnica liczb = " + (liczba1 - liczba2));
                break;
            case 4:
                System.out.println("Iloraz liczb = " + (liczba1 / liczba2));
                break;
        }

            int iloczyn = 1;
            int [] tab2 = {scanner.nextInt(),scanner.nextInt(),scanner.nextInt()};

            for (int liczba : tab2){
                  iloczyn*=liczba;
                }
                System.out.println(iloczyn);



        }
    }

