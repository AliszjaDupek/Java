public class Metody {
    public static void main(String[] args){
        przywitanie("Alicja",14,170);
        System.out.println(dodawanie(6,4));
    }

    public static void przywitanie(String imie, int wiek, double wzrost){
        System.out.println("Czesc "+imie+"!");


    }

    public static int dodawanie(int liczba1, int liczba2){
        int wynik = liczba1+liczba2;
        return wynik;
    }
}
