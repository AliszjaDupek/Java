import java.util.Scanner;
public class Zadanie {
    public static void main(String[] args){
//        int [] tab = new int[3];
//        wyswietlTablice(tablica(tab));
        int [] tab = {2,3,4,5,6};
        add(tab);
    }

    public static int[] tablica(int[] tablica){
        for ( int i = 0; i<tablica.length; i++){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Podaj liczbe");
            tablica[i]=scanner.nextInt();

        }
        return tablica;
    }
    public static void add(int[] tablica) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Na którym miejscu chcesz zamienic liczbe?");
            int index = scanner.nextInt();
            while (index < 1 || index > 5) {
                System.out.println("Liczba wykracza poza index, podaj inna liczbe");
                index = scanner.nextInt();
            }
            System.out.println("Podaj liczbe");
            tablica[index - 1] = scanner.nextInt();
            wyswietlTablice(tablica);

            }




    public static void wyswietlTablice(int[] tablica){
        for(int i : tablica){
            System.out.println(i);
        }
    }

}
