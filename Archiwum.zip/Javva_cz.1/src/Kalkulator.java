import java.util.Scanner;

public class Kalkulator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        dodaj(scanner.nextFloat(), scanner.nextFloat());
        odejmij(scanner.nextFloat(), scanner.nextFloat());
        mnozenie(scanner.nextFloat(), scanner.nextFloat());
        dzielenie(scanner.nextFloat(), scanner.nextFloat());
    }
    public static void dodaj(float liczba1, float liczba2){
        System.out.println(liczba1 + liczba2);
    }

    public static void odejmij(float liczba1,float liczba2){
        System.out.println(liczba1-liczba2);
    }

    public static void mnozenie(float liczba1,float liczba2){
        System.out.println(liczba1*liczba2);
    }
    public static void dzielenie(float liczba1, float liczba2){
        System.out.println(liczba1/liczba2);
    }

}
