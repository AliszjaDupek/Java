public class UjemnyWiekException extends Exception{
    public UjemnyWiekException(String message){
        super(message);
    }
}
