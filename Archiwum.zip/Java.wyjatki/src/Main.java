public class Main {
    public static void main(String[] args) {
//        Kalkulator k1 = new Kalkulator(90,0);
//        try{
//            Osoba o1 = new Osoba("Jan", "Kowalski", -10);
//        } catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
//            System.out.println(e.getMessage());
//        }
//        try{
//            Osoba o1 = new Osoba(null, "Kowalski", 10);
//        } catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
//            System.out.println(e.getMessage());
//        }
        try{
            Osoba o1 = new Osoba(null, "Kowalski", -10);
        }
        catch (UjemnyWiekException | NieprawidlowaWartoscException e) {
            System.out.println(e.getMessage());
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
//
//
////
////        try{
////            System.out.println(podziel(10,2));
////            System.out.println("Poprawnie wykonano");
////        } catch (ArithmeticException e){
////            System.out.println(e.getMessage());
////            System.out.println("Złapał wyjątek");
////        } finally {
////            System.out.println("Koniec ryzykowanych operacji");
////        }
////
////        try{
////            System.out.println(podziel(10,0));
////            System.out.println("Poprawnie wykonano");
////        } catch (ArithmeticException e){
////            System.out.println(e.getMessage());
////            System.out.println("Złapał wyjątek");
////        } finally {
////            System.out.println("Koniec ryzykowanych operacji");
////        }
////
////
////    }
////
////
////    public static int podziel(int a, int b){
////        return a/;
////        boolean czyPodanoWiek = false;
////        int wiek = 0;
////        while(!czyPodanoWiek){
////            try {
////                System.out.println("Podaj wiek: ");
////                wiek = getInt();
////                czyPodanoWiek=true;
////            } catch (InputMismatchException e){
////                System.out.println("Musisz podać wiek");
////            }finally {
////                System.out.println(wiek);
////            }
////        }
//    }
//    public static int getInt(){
//      return new Scanner(System.in).nextInt();

    }
    public static int silnia(int n){
        int s=0;
        for(int i=0; i<n+1; i++){
            s+=i;
        }
        return s;
    }


}