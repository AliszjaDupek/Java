public class UjemnaLiczbaException extends Exception {
    public UjemnaLiczbaException(String message) {
        super(message);
    }
}

