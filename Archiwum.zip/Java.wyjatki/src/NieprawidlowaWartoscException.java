public class NieprawidlowaWartoscException extends Exception{
    public NieprawidlowaWartoscException(String message) {
        super(message);
    }
}
