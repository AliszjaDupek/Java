public class Osoba {
    private int wiek;
    private String imie;
    private String nazwisko;

    public Osoba(String imie, String nazwisko, int wiek) throws UjemnyWiekException, NieprawidlowaWartoscException {
        if (imie==null){
            throw new NieprawidlowaWartoscException("Musisz podac imie");
        }
        if(wiek<0) {
            throw new UjemnyWiekException("Wiek nie może być ujemny");
        }
        if (nazwisko==null){
            throw new NieprawidlowaWartoscException("Musisz podac imie");
        }
        if(wiek<0) {
            throw new UjemnyWiekException("Wiek nie może być ujemny");
            }

        this.wiek=wiek;
        this.imie=imie;
        this.nazwisko=nazwisko;

    }


}
