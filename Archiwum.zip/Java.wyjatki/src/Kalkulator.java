public class Kalkulator {
    private int liczba1;
    private int liczba2;

    public Kalkulator(int liczba1, int liczba2){
        this.liczba1=liczba1;
        this.liczba2=liczba2;
    }

    public void podziel() {
        if (liczba2 == 0) {
            throw new IllegalArgumentException("Nie mozna dzielic przez 0");
        } else {
            System.out.println(liczba1 / liczba2);
        }
    }


}
