public class MojaListaZwierzat {
    private Zwierze[] zwierzeta;
    private int index;

    public MojaListaZwierzat(){
        this.index=0;
        zwierzeta=new Zwierze[6];
    }

    public void dodaj(Zwierze p){
        if(index< zwierzeta.length){
            zwierzeta[index]=p;
            System.out.println("Dodana psa na pozycji :"+ index);
            index++;
        }
    }

    public Zwierze get(int i){
        if(i>=0 || i< zwierzeta.length){
            return zwierzeta[i];
        }else{
            return null;
        }
    }
}
