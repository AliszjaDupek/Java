public abstract class Zwierze {

}
