public class Main {
    public static void main(String[] args) {
        Pies p1 = new Pies();
        Pies p2 = new Pies();
        Pies p3 = new Pies();
//
//        MojaListaPsow listaPsow = new MojaListaPsow();
//        listaPsow.dodaj(p1);
//        listaPsow.dodaj(p2);
//        listaPsow.dodaj(p3);
        Kot k1 = new Kot();
        Kot k2 = new Kot();
        Kot k3 = new Kot();

        MojaListaZwierzat listaZwierzat = new MojaListaZwierzat();
        listaZwierzat.dodaj(p1);
        listaZwierzat.dodaj(p2);
        listaZwierzat.dodaj(p3);
        listaZwierzat.dodaj(k1);
        listaZwierzat.dodaj(k2);
        listaZwierzat.dodaj(k3);

        System.out.println(k1.getClass());
        System.out.println(p1.getClass());

        System.out.println(k1.hashCode());
        System.out.println(p1.hashCode());

        if(p1.equals(p2)){
            System.out.println("prawda");
        }
        else{
            System.out.println("fałsz");
        }

        Zwierze z1 = listaZwierzat.get(4);
        System.out.println(z1.getClass());


        if(z1 instanceof Pies){
            Pies piesek = (Pies) z1;
            piesek.dajGlos();
        } else {
            Kot kotek = (Kot) z1;
            kotek.dajGlos();
        }
    }
}