public class Kot extends Zwierze{
    public void dajGlos(){
        System.out.println("Miau");
    }
}
