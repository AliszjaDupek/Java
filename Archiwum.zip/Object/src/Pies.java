public class Pies extends Zwierze{
    public void dajGlos(){
        System.out.println("Hau hau");
    }
}
