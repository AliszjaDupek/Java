public class MojaListaPsow {
    private Pies[] psy;
    private int index;

    public MojaListaPsow(){
        this.index=0;
        psy=new Pies[6];
    }

    public void dodaj(Pies p){
        if(index< psy.length){
            psy[index]=p;
            System.out.println("Dodana psa na pozycji :"+ index);
            index++;
        }
    }
}
