public class Pies {
    private String rasa;
    private String imie;
    private Wlasciciel wlasciciel;
    //konstruktory
    public Pies(){
        rasa="Boston terrier";
        imie="Luna";
        wlasciciel=new Wlasciciel();
    }
    public Pies(String rasa, String imie, Wlasciciel wlasciciel){
        this.rasa=rasa;
        this.imie=imie;
        this.wlasciciel=wlasciciel;
    }
    //set
    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setRasa(String rasa) {
        this.rasa = rasa;
    }
    public void setWlasciciel(Wlasciciel wlasciciel) {
        this.wlasciciel = wlasciciel;
    }

    //get
    public Wlasciciel getWlasciciel() {
        return wlasciciel;
    }
    public String getRasa() {
        return rasa;
    }
    public String getImie() {
        return imie;
    }
    public String toString(){
        return rasa+" "+imie+" "+wlasciciel.toString();
    }


}
