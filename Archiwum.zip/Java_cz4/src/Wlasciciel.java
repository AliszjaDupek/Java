public class Wlasciciel {
    private String imie;
    private String nazwisko;

    //Konstruktor
    public Wlasciciel(){
        imie="Jan";
        nazwisko="Kowalski";
    }
    public Wlasciciel(String imie, String nazwisko){
        this.imie=imie;
        this.nazwisko=nazwisko;
    }
    //get
    public String getNazwisko() {
        return nazwisko;
    }
    public String getImie() {
        return imie;
    }
    //set
    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    public String toString(){
        return imie+" "+nazwisko;
    }
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
    @Override
    public int hashCode() {
        return super.hashCode();
    }
}


