public class Kot extends Zwierze{
    private String imie;
    private Wlasciciel wlasciciel;

    public Kot(){
        imie="Azor";
        wlasciciel=new Wlasciciel();
    }
    public Kot(String imie, Wlasciciel wlasciciel){
        this.imie=imie;
        this.wlasciciel=wlasciciel;
    }

    public Kot(String imie, Wlasciciel wlasciciel, int wiek, String gatunek, int poziomGlodu){
        super(wiek, gatunek, poziomGlodu);
        this.imie=imie;
        this.wlasciciel=wlasciciel;
    }

    public Kot(int wiek){
        super(wiek, "ssak", 20);
            imie="Tygrys";
            wlasciciel=new Wlasciciel();
    }

    //set
    public void setWlasciciel(Wlasciciel wlasciciel) {
        this.wlasciciel = wlasciciel;
    }
    public void setImie(String imie) {
        this.imie=imie;
    }
    //get
    public String getImie() {
        return imie;
    }
    public Wlasciciel getWlasciciel() {
        return wlasciciel;
    }

    //toString
    @Override
    public String toString() {
        return super.toString()+" "+imie+" "+wlasciciel;
    }
    @Override
    public void whoAmI(){
        super.whoAmI();
        System.out.println("Jestem kotem");
    }
}
