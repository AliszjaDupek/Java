public class Zwierze {
    protected int wiek;
    protected String gatunek;
    protected int poziomGlodu;

    //kon
    public Zwierze(){
        wiek=2;
        gatunek="ssak";
        poziomGlodu=5;
    }
    public Zwierze(int wiek, String gatunek, int poziomGlodu){
        this.wiek=wiek;
        this.poziomGlodu=poziomGlodu;
        this.gatunek=gatunek;
    }
    //set
    public void setPoziomGlodu(int poziomGlodu) {
        this.poziomGlodu = poziomGlodu;
    }
    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }
    public void setWiek(int wiek) {
        this.wiek = wiek;
    }
    //get
    public int getPoziomGlodu() {
        return poziomGlodu;
    }
    public String getGatunek() {
        return gatunek;
    }
    public int getWiek() {
        return wiek;
    }
    //toString
    public String toString() {
        return gatunek+" "+wiek+" "+poziomGlodu+" ";
    }
    public void whoAmI(){
        System.out.println("Jestem zwierzem");
    }
}
