public class Main {
    public static void main(String[] args) {
        Zwierze zwierze1 = new Zwierze();
        Zwierze zwierze2 = new Kot();
        Kot kot1 = new Kot();
        Kot kot2 = new Kot("Kulka",new Wlasciciel("Alicja","Dudek"), 7,"ssak",50);

        System.out.println("Zwierze 1: "+zwierze1.toString());
        System.out.println("Zwierze 2: "+zwierze2.toString());
        System.out.println("Kot 1: "+kot1.toString());
        System.out.println("Kot 2: "+kot2.toString());
        kot1.whoAmI();
        kot2.whoAmI();
        zwierze1.whoAmI();
        zwierze2.whoAmI();
//        Wlasciciel wlasciciel1 = new Wlasciciel();
//        Wlasciciel wlasciciel2 = new Wlasciciel("Alicja","Dudek");
//        Pies pies1 = new Pies();
//        Pies pies2 = new Pies("Jamnik", "Sona",wlasciciel2);
//
//        System.out.println("Własciciel 1: "+wlasciciel1.toString());
//        System.out.println("Własciciel 2: "+wlasciciel2.toString());
//
//        System.out.println("Pies 1: "+pies1.toString());
//        System.out.println("Pies 2: "+pies2.toString());


    }
}