import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Podaj metode platnosci");
//        String metoda = scanner.next();
//        PlatnoscNiepoprawna platnoscNiepoprawna = new PlatnoscNiepoprawna();
//        platnoscNiepoprawna.zaplac(metoda);
//        Scanner scanner = new Scanner(System.in);
//        Platnosc platnosc = new Platnosc(45.99);
//        System.out.println("Wybierz sposob platnosc(1 = blik, 2 = karta)");
//        int wybor = scanner.nextInt();
//        switch (wybor){
//            case (1):
//                platnosc.setStrategy(new PlatnoscBlik());
//                platnosc.zaplac();
//                break;
//            case (2):
//                platnosc.setStrategy(new PlatnoscKarta());
//                platnosc.zaplac();
//                break;
//            default:
//                System.out.println("Nie wybrales wyboru platnosci");
//                break;
//        }
        Ksiazka k1 = new Ksiazka();
        Ksiazka k2 = new Ksiazka();
        Ksiazka k3 = new Ksiazka();
        Ksiazka k4 = new Ksiazka();
        Ksiazka k5 = new Ksiazka();
        Ksiazka k6 = new Ksiazka();
        Koszyk koszyk = new Koszyk();
        boolean odpowiedz=true;
        System.out.println("Oto lista książek : \n"+"nr1 ="+k1.toString()+"\n"+"nr2 ="+k2.toString()+"\n"+"nr3 ="+k3.toString()+"\n"+"nr4 ="+k4.toString()+"\n"+"nr5 ="+k5.toString()+"\n"+"nr6 ="+k6.toString());
        while(odpowiedz == true){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Wybierz operacje(1 = Dodaj do koszyka, 2 = Usun z Koszyka,3 = wyswietl Koszyk, 4 = wyswietl liste ksiazek, 5 = zakoncz zakupy, 6 = kup ksiazki)");
            int wybor = scanner.nextInt();
            switch (wybor){
                case(1):
                    System.out.println("Podaj numer ksiazki");
                    int odpo = scanner.nextInt();
                    switch (odpo) {
                        case (1):
                            koszyk.dodajDoKorzyka(k1);
                            break;
                        case (2):
                            koszyk.dodajDoKorzyka(k2);
                            break;
                        case (3):
                            koszyk.dodajDoKorzyka(k3);
                            break;
                        case (4):
                            koszyk.dodajDoKorzyka(k4);
                            break;
                        case (5):
                            koszyk.dodajDoKorzyka(k5);
                            break;
                        case (6):
                            koszyk.dodajDoKorzyka(k6);
                            break;
                    }
                    break;
                case(2):
                    System.out.println("Podaj index");
                    int o = scanner.nextInt();
                    koszyk.usunZKoszyka(o);
                    break;
                case(3):
                    koszyk.wyswietlKoszyk();
                    break;
                case(4):
                    System.out.println("Oto lista książek : \n"+"nr1 ="+k1.toString()+"\n"+"nr2 ="+k2.toString()+"\n"+"nr3 ="+k3.toString()+"\n"+"nr4 ="+k4.toString()+"\n"+"nr5 ="+k5.toString()+"\n"+"nr6 ="+k6.toString());
                    break;
                case(5):
                    odpowiedz=false;
                    break;
                case(6):
                    Platnosc platnosc = new Platnosc(koszyk.cenaSuma);
                    System.out.println("Wybierz sposob platnosc(1 = blik, 2 = karta)");
                    int wybo = scanner.nextInt();
                    switch (wybo){
                        case (1):
                            platnosc.setStrategy(new PlatnoscBlik());
                            platnosc.zaplac();
                            break;
                        case (2):
                            platnosc.setStrategy(new PlatnoscKarta());
                            platnosc.zaplac();
                            break;
                        default:
                            System.out.println("Nie wybrales wyboru platnosci");
                            break;
                    }
            }
        }
    }
}