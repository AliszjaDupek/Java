public class Ksiazka {
    protected String tytul;
    protected String autor;
    protected double cena;

    public Ksiazka(){
        tytul="Pan Tadeusz";
        autor="Adam Mickiewicz";
        cena=35.99;
    }

    public String getTytul() {
        return tytul;
    }
    public String getAutor() {
        return autor;
    }
    public double getCena() {
        return cena;
    }
    public void setTytul(String tytul) {
        this.tytul = tytul;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public void setCena(double cena) {
        this.cena = cena;
    }

    @Override
    public String toString() {
        return "Ksiazka{" +
                "tytul='" + tytul + '\'' +
                ", autor='" + autor + '\'' +
                ", cena=" + cena +
                '}';
    }

}
