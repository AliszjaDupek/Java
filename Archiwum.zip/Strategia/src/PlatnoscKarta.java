public class PlatnoscKarta implements PlatnoscStrategy{
    private Karta karta = new Karta();

    @Override
    public void zaplac(double kwota) {
        karta=new Karta();
        System.out.println("Placisz karta");
        System.out.println(karta.getStanKonta());
        karta.setStanKonta(karta.getStanKonta() - kwota);
        System.out.println(karta.getStanKonta());
    }

    @Override
    public boolean czyMozliwa() {
        if(karta.getStanKonta()<=0){
            return false;
        }
        return true;
    }
}
