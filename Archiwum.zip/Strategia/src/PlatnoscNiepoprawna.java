import java.sql.SQLOutput;
import java.util.Scanner;

public class PlatnoscNiepoprawna {
    private double suma = 23.99;
    public void zaplac(String metoda){
        Scanner scanner = new Scanner(System.in);
        if(metoda.equals("Blik")){
            System.out.println("Placisz blikiem");
            int kod = scanner.nextInt();
            System.out.println("Twój kod : " + kod);
        } else if (metoda.equals("Karta")) {
            Karta karta= new Karta();
            System.out.println("Placisz karta");
            karta.setStanKonta(karta.getStanKonta() - suma);
            System.out.println(karta.getStanKonta());
        }
    }
}
