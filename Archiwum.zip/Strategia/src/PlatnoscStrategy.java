public interface PlatnoscStrategy {
    void zaplac(double kwota);
    boolean czyMozliwa();
}
