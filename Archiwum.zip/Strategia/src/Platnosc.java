public class Platnosc {
    private double kwota;
    private PlatnoscStrategy strategy;

    public Platnosc(){
        kwota=100.23;
    }

    public Platnosc(double kwota){
        this.kwota=kwota;
    }

    public void setStrategy(PlatnoscStrategy strategy){
        this.strategy=strategy;
    }

    public void zaplac(){
        if(strategy.czyMozliwa()){
            strategy.zaplac(kwota);
        }
    }
}
