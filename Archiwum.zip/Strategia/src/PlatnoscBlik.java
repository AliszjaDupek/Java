import java.util.Scanner;

public class PlatnoscBlik implements PlatnoscStrategy{
    private int kod = 0;

    @Override
    public void zaplac(double kwota) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Placisz blikiem");
        kod = scanner.nextInt();
        if (czyMozliwa()){
            System.out.println("Prawidlowy kod, twój kod : " + kod);
            System.out.println("Kwota: "+kwota);
        }else{
            System.out.println("Zly kod");
        }

    }

    @Override
    public boolean czyMozliwa() {
                return true;

    }
}
