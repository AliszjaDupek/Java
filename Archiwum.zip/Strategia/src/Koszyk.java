public class Koszyk extends Ksiazka {
    protected Ksiazka[] tablicaKsiazek;
    public double cenaSuma;
    protected int pojemnoscKoszyka;
    protected int index;

    public Koszyk(){
        pojemnoscKoszyka=10;
        tablicaKsiazek=new Ksiazka[pojemnoscKoszyka];
        double cenaSuma=0;
        for(int i =0; i< tablicaKsiazek.length;i++){
            if(tablicaKsiazek[i]!=null)
                cenaSuma=cenaSuma+tablicaKsiazek[i].getCena();
        }
        index=0;
    }
    public void wyswietlKsiazki(){
        for(int i=0; i< tablicaKsiazek.length; i++){
            System.out.println(tablicaKsiazek[i].toString());
        }
    }

    public void dodajDoKorzyka(Ksiazka ksiazka){
        if(index>=0 && index<tablicaKsiazek.length){
            tablicaKsiazek[index]=ksiazka;
            index++;
        }
    }
    public void usunZKoszyka(int index){
        if(index>=0 && index< tablicaKsiazek.length){
            tablicaKsiazek[index]=null;
        }
    }
    public void wyswietlKoszyk(){
        for(int i=0; i< tablicaKsiazek.length; i++){
            if(tablicaKsiazek[i]!=null){
                System.out.println(tablicaKsiazek[i].toString());
            }
        }
    }


}
