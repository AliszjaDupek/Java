public class Karta {
    private double stanKonta;
    private String numer;
    private String dataWaznosci;
    private int CVV;

    public Karta(){
        stanKonta = 1000;
        numer = "1234 1234 1234 1244";
        dataWaznosci = "08/24";
        CVV = 123;
    }

    public double getStanKonta(){
        return stanKonta;
    }

    public void setStanKonta(double stanKonta) {
        this.stanKonta = stanKonta;
    }
}
