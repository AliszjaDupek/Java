public class Zwierze {
    public String gatunek;
    public int wiek;

    public Zwierze(String gatunek, int wiek){
        this.wiek=wiek;
        this.gatunek=gatunek;
        System.out.println("Jestem zwierzem");
    }
    public Zwierze(){
        gatunek="ssak";
        wiek=10;
        System.out.println("Jestem zwierzem");
    }
    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }
    public void setWiek(int wiek) {
        this.wiek = wiek;
    }
    public String getGatunek() {
        return gatunek;
    }
    public int getWiek() {
        return wiek;
    }
    @Override
    public String toString(){
        return gatunek+" "+wiek;
    }

}
