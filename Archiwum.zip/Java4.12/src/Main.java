public class Main {
    public static void main(String[] args) {
        Zwierze z1 = new Zwierze();
        Kot k1 = new Kot();

        Zwierze z2 = new Kot();
        //Kot k2 = (Kot) new Zwierze();

        ((Kot)z2).setImie("Milusia");

    przedstawSie(z2);
    przedstawSie(z1);
    przedstawSie(k1);

    }

    public static void przedstawSie(Zwierze z){
        System.out.println("Cześć! "+z);
    }
}