public class Kot extends Zwierze {
    public String imie;

    public Kot(){
        super("ssak",10);
        imie="Torpeda";
        System.out.println("Jestem kotem");
    }
    public Kot(String imie){
        super("ssak",10);
        this.imie=imie;
        System.out.println("Jestem kotem");
    }
    public Kot(String gatunek, int wiek, String imie){
        super(gatunek, wiek);
        this.imie=imie;
        System.out.println("Jestem kotem");
    }
    public String getImie() {
        return imie;
    }
    public void setImie(String imie) {
        this.imie = imie;
    }
    @Override
    public String toString(){
        return super.toString()+" "+imie;
    }

}
