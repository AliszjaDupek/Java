import java.io.Serializable;

public class Adres implements Serializable {
    transient protected String ulica;
    transient protected int nrDomu;
    transient protected int nrMieszkania;
    protected String kodPocztowy;
    protected String miejscowosc;

    public Adres(){
        ulica="Owocowa";
        nrDomu=117;
        nrMieszkania=0;
        kodPocztowy="2093876-98";
        miejscowosc="Leszno";
    }

    public Adres(String ulica, int nrDomu, int nrMieszkania, String kodPocztowy, String miejscowosc){
        this.ulica=ulica;
        this.miejscowosc=miejscowosc;
        this.kodPocztowy=kodPocztowy;
        this.nrMieszkania=nrMieszkania;
        this.nrDomu=nrDomu;
    }

    @Override
    public String toString() {
        return "Adres{" +
                "ulica='" + ulica + '\'' +
                ", nrDomu=" + nrDomu +
                ", nrMieszkania=" + nrMieszkania +
                ", kodPocztowy='" + kodPocztowy + '\'' +
                ", miejscowosc='" + miejscowosc + '\'' +
                '}';
    }
}
