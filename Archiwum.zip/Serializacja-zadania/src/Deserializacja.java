import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Deserializacja {
    public static void main(String[]args){
        try{
            FileInputStream stream = new FileInputStream("obiekty.ser");
            ObjectInputStream os = new ObjectInputStream(stream);

            Object ob1 = os.readObject();
            Object ob2 = os.readObject();

            Adres a1 = (Adres) ob1;
            Adres a2 = (Adres) ob2;
            System.out.println(a1);
            System.out.println(a2);

            os.close();
        }
        catch(IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
    }
}
