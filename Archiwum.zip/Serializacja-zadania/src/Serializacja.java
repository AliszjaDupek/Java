import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serializacja {
    public static void main(String[]args) {
        Adres adres1 = new Adres();
        Adres adres2 = new Adres("Miodowa", 118, 0, "98765-98", "Gronowo");

        System.out.println(adres1.toString());
        System.out.println(adres2.toString());

        File file = new File("obiekty.ser");
        try {
            FileOutputStream stream = new FileOutputStream(file);
            ObjectOutputStream so = new ObjectOutputStream(stream);

            so.writeObject(adres1);
            so.writeObject(adres2);
            so.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }


}
