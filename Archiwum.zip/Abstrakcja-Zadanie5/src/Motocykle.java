public class Motocykle extends Pojazd{
    String marka;
    int dopuszczalnaIloscPasazerow;
    public Motocykle(){
        marka="Yamaha";
        dopuszczalnaIloscPasazerow=2;
    }
    @Override
    public void jedz() {
        System.out.println("pedze");
    }
}
