public abstract class Pojazd {
    String nrRejestracyjny;
    String kolor;
    int cena;
    int spalanie;
    int licznikKM;
    int zbiornikPaliwa;
    int maxPojemnoscZbiornika;

    public Pojazd() {
        nrRejestracyjny="ds043987";
        kolor="czarny";
        cena=150000;
        spalanie=5;
        zbiornikPaliwa=10;
        maxPojemnoscZbiornika=55;
        licznikKM=0;

    }

    public void tankuj(){
        zbiornikPaliwa=maxPojemnoscZbiornika;
    }
    public abstract void jedz();
}
