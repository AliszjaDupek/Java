public class Osobowe extends Pojazd{
    int liczbaDrzwi;
    String marka;
    public Osobowe(){
        liczbaDrzwi = 4;
        marka="Audi";
    }
    @Override
    public void jedz() {
        System.out.println("Jade");
    }

}
