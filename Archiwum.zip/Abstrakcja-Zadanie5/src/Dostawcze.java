public class Dostawcze extends Pojazd{
    int ograniczeniePredkosci;
    int ladownosc;
    public Dostawcze(){
        ograniczeniePredkosci=120;
        ladownosc=3;
    }
    @Override
    public void jedz() {
        System.out.println("Dowoze");
    }
}
