public class Main {
    public static void main(String[] args) {
        Dostawcze d = new Dostawcze();
        Motocykle m = new Motocykle();
        Osobowe o = new Osobowe();

        d.jedz();
        m.jedz();
        o.jedz();
        System.out.println(o.zbiornikPaliwa);
        o.tankuj();
        System.out.println(o.zbiornikPaliwa);
    }
}