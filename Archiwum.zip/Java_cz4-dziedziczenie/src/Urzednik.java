public class Urzednik extends Pracownik{
    protected String stanowisko;
    protected int premia;

    //Konstruktory : domyślny
    public Urzednik(){
        stanowisko="informatyk";
        premia=50;
    }
    //przeciazony
    public Urzednik(String stanowisko, int premia){
        this.premia=premia;
        this.stanowisko=stanowisko;
    }
    public Urzednik(int premia, String stanowisko, int liczbaGodzin, int stawka){
        this.premia=premia;
        this.stawka=stawka;
        this.liczbaGodzin=liczbaGodzin;
        this.stanowisko=stanowisko;
    }
    public Urzednik(int premia, String stanowisko, int liczbaGodzin, int stawka, String imie, String nazwisko, String pesel){
        this.premia=premia;
        this.stawka=stawka;
        this.liczbaGodzin=liczbaGodzin;
        this.stanowisko=stanowisko;
        this.nazwisko=nazwisko;
        this.imie=imie;
        this.pesel=pesel;
    }
    //Metody : set
    public void setStanowisko(String stanowisko) {
        this.stanowisko = stanowisko;
    }
    public void setPremia(int premia) {
        this.premia = premia;
    }
    //get
    public String getStanowisko() {
        return stanowisko;
    }
    public int getPremia() {
        return premia;
    }

    //toString
    public String toString(){
        return "Stanowisko: "+stanowisko+"\nPremia: "+premia;
    }

    public void przedstawSie(){
        System.out.println("Jestem urzędnikiem");
    }

    @Override
    public int obliczPensje() {
        return super.obliczPensje()+premia;
    }
}
