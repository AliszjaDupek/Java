public class Pracownik extends Osoba{
    protected int liczbaGodzin;
    protected int stawka;

    //konstruktory : domyślny
    public Pracownik(){
        liczbaGodzin=100;
        stawka=98;
    }
    //
    public Pracownik(int liczbaGodzin, int stawka){
        this.liczbaGodzin=liczbaGodzin;
        this.stawka=stawka;
    }
    public Pracownik(int liczbaGodzin, int stawka, String nazwisko, String imie, String pesel){
        this.liczbaGodzin=liczbaGodzin;
        this.stawka=stawka;
        this.nazwisko=nazwisko;
        this.imie=imie;
        this.pesel=pesel;
    }
    //set
    public void setStawka(int stawka) {
        this.stawka = stawka;
    }
    public void setLiczbaGodzin(int liczbaGodzin) {
        this.liczbaGodzin = liczbaGodzin;
    }
    //get
    public int getStawka() {
        return stawka;
    }
    public int getLiczbaGodzin() {
        return liczbaGodzin;
    }
    //Metody: przedstawSie
    public void przedstawSie(){
        System.out.println("Jestem pracownikiem");
    }
    //oblicz pensje
    public int obliczPensje(){
        return stawka*liczbaGodzin;
    }

    public String toString(){
        return "Liczba godzin: "+liczbaGodzin+"\nstawka: "+stawka;
    }
}
