public class Osoba {
    protected String nazwisko;
    protected String imie;
    protected String pesel;

    //konstruktory
    //domyślny:
    public Osoba(){
        imie="Jan";
        nazwisko="Kowalski";
        pesel="12345678";
    }
    //przeciazone
    public Osoba(String imie, String nazwisko, String pesel){
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.pesel=pesel;
    }
    public Osoba(String imie, String nazwisko){
        this.imie=imie;
        this.nazwisko=nazwisko;
    }
    //get
    public String getPesel() {
        return pesel;
    }
    public String getNazwisko() {
        return nazwisko;
    }
    public String getImie() {
        return imie;
    }
    //set
    public void setPesel(String pesel) {
        this.pesel = pesel;
    }
    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    public void setImie(String imie) {
        this.imie = imie;
    }
    //Metody : toString
    public String toString(){
        return "Imie: "+imie+"\nNazwisko: "+nazwisko+"\nPesel: "+pesel;
    }

    public void przedstawSie(){
        System.out.println("Jestem osobą");
    }

}
