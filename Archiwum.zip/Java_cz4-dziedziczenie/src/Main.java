public class Main {
    public static void main(String[] args) {
        //Osoba:
        Osoba os1 = new Osoba();
        Osoba os2 = new Osoba("Jan", "Kowalski");
        Osoba os3 = new Osoba("Alicja", "Dudek", "123342343");
        System.out.println("Osoba 2----- \n"+os2.toString());
        os2.przedstawSie();
        System.out.println();
        System.out.println("Osoba 3----- \n"+os3.toString());
        os3.przedstawSie();
        System.out.println();
        //Pracownik:
        Osoba os_p1 = new Pracownik();
        Pracownik p2 = new Pracownik(50,100,"Kowalska","Iga","192386348");
        Pracownik p3 = new Pracownik(100,98);
        System.out.println("Pracownik 2-----\n"+p2.toString());
        p2.przedstawSie();
        System.out.println();
        System.out.println("Pracownik/Osoba 1-----\n"+os_p1.toString());
        os_p1.przedstawSie();
        System.out.println();
        System.out.println("Pracownik 2 - pensja : "+p2.obliczPensje());
        //Urzednik:
        Osoba urz1 = new Urzednik();
        Pracownik urz2 = new Urzednik(100, "jakies", 50, 98);
        System.out.println();
        System.out.println("Urzednik 2-----\n"+urz2.toString());
        urz2.przedstawSie();
        System.out.println();
        System.out.println("Pensja - Urzednik2 : "+urz2.obliczPensje());
        System.out.println();
    }
}