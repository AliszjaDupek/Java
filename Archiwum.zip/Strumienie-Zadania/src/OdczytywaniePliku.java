import java.io.File;
import java.io.IOException;

public class OdczytywaniePliku {
    public static void main(String[] args) {
        File file = new File("Plik.txt");
        int licznik=0;
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
        try{
            String[] lista = file.list();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        System.out.println("Liczba znaków: "+licznik);
    }
}
