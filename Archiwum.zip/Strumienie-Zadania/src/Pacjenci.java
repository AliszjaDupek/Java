import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Pacjenci {
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
        File file = new File("Pacjenci.txt");
        boolean podajPacjenta=true;
        String imie;
        String nazwisko;
        String dataUrodzenia;
        String pesel;
        String odpowiedz;
        while(podajPacjenta){
            System.out.println("Podaj imie : ");
            imie=scanner.next();
            System.out.println("Podaj nazwisko : ");
            nazwisko=scanner.next();
            System.out.println("Podaj date urodzenia : ");
            dataUrodzenia=scanner.next();
            System.out.println("Podaj pesel");
            pesel=scanner.next();
            System.out.println("Czy chcesz dodac nowego pacjenta?");
            odpowiedz=scanner.next();

            try {
                FileWriter writer = new FileWriter("pacjenci.txt",true);
                BufferedWriter buffer = new BufferedWriter(writer);
                buffer.newLine();
                buffer.write("Imię: " + imie);
                buffer.newLine();
                buffer.write("Nazwisko: " + nazwisko);
                buffer.newLine();
                buffer.write("Data urodzenia: " + dataUrodzenia);
                buffer.newLine();
                buffer.write("Pesel: " + pesel);
                buffer.newLine();
                buffer.write("--------------------------");
                buffer.newLine();
                buffer.close();
                if(odpowiedz.equals("nie")) {
                    podajPacjenta = false;
                    break;
                }
            }catch(IOException e){
                System.out.println(e.getMessage());
            }
        }
    }
}
