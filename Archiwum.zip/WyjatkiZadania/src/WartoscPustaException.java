public class WartoscPustaException extends Exception {
    public WartoscPustaException(String message){
        super(message);
    }

}
