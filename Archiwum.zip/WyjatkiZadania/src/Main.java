public class Main {
    public static void main(String[] args) throws BlednyWpisException {
        try{
            silnia(-6);
        } catch (BlednaWartoscException e) {
            System.out.println(e);
        }
        try{
            silnia(6);
        } catch (BlednaWartoscException e) {
            System.out.println(e);
        }

        try {
            Nauczyciel n1 = new Nauczyciel(null, "K", "Fizyka", null);
        } catch (WartoscPustaException e){
            System.out.println(e);
        }

        try {
            Nauczyciel n1 = new Nauczyciel("Jan", "K", null, "Owocowa 1");
        } catch (WartoscPustaException e){
            System.out.println(e);
        }

        Student s1 = new Student();
        try{
            s1.DodajOcene(6,6);
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println(e);
        }

        try{
            s1.DodajOcene(5,6);
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println(e);
        }

        try {
            Student s2 = new Student(null, "Ala", -5, null, "");
        }catch(BlednyWpisException e){
            System.out.println(e);
        }
    }
    public static int silnia(int n) throws BlednaWartoscException{
        if(n>0) {
            int w = 0;
            for (int i = 0; i < n + 1; i++) {
                w += i;
            }
            System.out.println("Brak bledow, wynik : "+w);
            return w;

        }
        else{
            throw new BlednaWartoscException("Liczba nie moze byc ujemna");
        }
    }
}