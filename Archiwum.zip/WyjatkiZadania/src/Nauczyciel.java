public class Nauczyciel {
    protected String imie;
    protected String nazwisko;
    protected String przedmiot;
    protected String adres;

    public Nauczyciel(){
        imie="Jan";
        nazwisko="Kowalski";
        przedmiot="Matematyka";
        adres="ul Owocowa 1";
    }
    public Nauczyciel(String imie, String nazwisko, String przedmiot, String adres) throws WartoscPustaException {
        if (imie == null) {
            throw new WartoscPustaException("Musisz podac imie");
        }
        if (nazwisko == null) {
            throw new WartoscPustaException("Musisz podac nazwisko");
        }
        if (przedmiot == null) {
            throw new WartoscPustaException("Musisz podac przedmiot");
        }

        this.imie = imie;
        this.nazwisko = nazwisko;
        this.przedmiot = przedmiot;
        this.adres = adres;
    }

}

