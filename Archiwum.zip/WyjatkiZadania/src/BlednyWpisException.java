public class BlednyWpisException extends Exception {
    public BlednyWpisException(String message) {
        super(message);
    }
}
