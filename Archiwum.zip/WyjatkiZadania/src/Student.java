import com.sun.jdi.IncompatibleThreadStateException;

import javax.print.DocFlavor;
import java.util.Scanner;

public class Student {
    protected String imie;
    protected String nazwisko;
    protected int indeks;

    protected String adres;
    public static double[] listaOcen = new double[6];

    public Student() {
        imie = "Jan";
        nazwisko = "Kowalski";
        indeks = 0;
        listaOcen[0] = 1;
        listaOcen[1] = 2;
        listaOcen[2] = 5;
    }

    public Student(String imie, String nazwisko, int indeks, double[] listaOcen, String adres) throws BlednyWpisException {
        if(imie==null){
            throw new BlednyWpisException("Musisz podac imie");
        }
        if(nazwisko==null){
            throw new BlednyWpisException("Musisz podac nazwisko");
        }
        if(adres==null){
            throw new BlednyWpisException("Musisz podac adres");
        }
        if (indeks> listaOcen.length || indeks<0){
            throw new BlednyWpisException("Niepoprawny indeks");
        }
            this.imie=imie;
            this.nazwisko=nazwisko;
            this.adres=adres;
            this.indeks=indeks;
            this.listaOcen = listaOcen;
        }
    public static double Ocena(int indeks){
        return listaOcen[indeks];
    }
    public static void DodajOcene(int indeks, int ocena){
        if (indeks>listaOcen.length-1 || indeks<0){
            throw new ArrayIndexOutOfBoundsException("Niepoprawny index");
        }
        else{
            listaOcen[indeks]=ocena;
            System.out.println("Brak bledow");
        }
    }


    }


