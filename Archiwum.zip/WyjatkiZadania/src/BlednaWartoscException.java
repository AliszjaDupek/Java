public class BlednaWartoscException extends Exception{
    public BlednaWartoscException(String message){
        super(message);
    }
}
