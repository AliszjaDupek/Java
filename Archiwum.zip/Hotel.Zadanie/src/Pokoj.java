public class Pokoj extends Osoba{
    protected int numer;
    protected Osoba klient;

    public Pokoj(){
        numer=101;
        klient=new Osoba();
    }
    public Pokoj(int numer, Osoba klient){
        this.numer=numer;
        this.klient=klient;
    }
    //get set
    public Osoba getKlient() {
        return klient;
    }
    public int getNumer() {
        return numer;
    }
    public void setNumer(int numer) {
        this.numer = numer;
    }
    public void setKlient(Osoba klient) {
        this.klient = klient;
    }
    public boolean czyWolnyPokoj(){
        if (klient==null){
            return true;
        }
        return false;
    }
    public void zwolijPokoj(){
        klient=null;
    }
}
