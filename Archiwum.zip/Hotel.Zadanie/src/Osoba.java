public class Osoba {
    protected String imie;
    protected String nazwisko;
    //konstruktory
    public Osoba(){
        imie="Jan";
        nazwisko="Kowalski";
    }
    public Osoba(String imie, String nazwisko){
        this.imie=imie;
        this.nazwisko=nazwisko;
    }
    //get,set
    public String getImie() {
        return imie;
    }
    public String getNazwisko() {
        return nazwisko;
    }
    public void setImie(String imie) {
        this.imie = imie;
    }
    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }
    @Override
    public String toString(){
        return imie+" "+nazwisko;
    }
    public boolean equals(Osoba osoba2){
        if((imie==osoba2.getImie())){
            if((nazwisko== osoba2.getNazwisko())){
                return true;}
            else{
                return false;
            }
        }else{return false;}
    }

}
