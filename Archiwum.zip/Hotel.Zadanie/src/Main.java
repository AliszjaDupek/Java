public class Main {
    public static void main(String[] args) {
        Osoba os1 = new Osoba();
        Osoba os2 = new Osoba();
        System.out.println(os1.equals(os2));
        Pokoj p1 = new Pokoj(102,os2);
        System.out.println(p1.czyWolnyPokoj());
        Hotel h1 = new Hotel();
        Osoba ok = new Osoba("Jan","Kowalski");
        h1.listaGosci();
        System.out.println(h1.ileWolnychPokoi());
        h1.listaWolnychPokoi();
        System.out.println(h1.znajdzWolnyPokoj());
        System.out.println(h1.czyOsobaWynajmuje(ok));
        h1.zwolnijZajetePrzez(ok);
        h1.listaGosci();
        h1.listaWolnychPokoi();
        System.out.println(h1.czyOsobaWynajmuje(ok));
        System.out.println(h1.znajdzWolnyPokoj());
        System.out.println(h1.ileWolnychPokoi());
        h1.wynajmijPokoj(ok);
        h1.listaWolnychPokoi();


    }
}