import java.lang.reflect.Array;

public class Hotel extends Pokoj {
    public Pokoj[][] hotel;
    protected int[] pokNaPietrze;

    public Hotel() {
        hotel = new Pokoj[3][3];
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                hotel[i][j] = new Pokoj(i * 100 + j, new Osoba());
            }
        }
    }

    @Override
    public String toString() {
        return klient.getImie() + klient.getNazwisko();
    }

    public int ileWolnychPokoi() {
        int liczba = 0;
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (hotel[i][j].czyWolnyPokoj() == true)
                    liczba++;
            }
        }
        return liczba;
    }

    public int znajdzWolnyPokoj() {
        int liczba = 0;
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (hotel[i][j].czyWolnyPokoj() == true)
                    return hotel[i][j].numer;
            }
        }
        return 0;
    }

    public void wynajmijPokoj(Osoba os) {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (i * 100 + j == znajdzWolnyPokoj()) {
                    hotel[i][j].setKlient(os);
                    break;
                }
            }
        }
    }

    public boolean czyWolnyPokoj(int numer) {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (i * 100 + j == numer) {
                    if (hotel[i][j].klient == null) {
                        return true;
                    }
                }
            }

        }
        return false;
    }

    public boolean czyOsobaWynajmuje(Osoba os) {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (hotel[i][j].klient==null) {
                    return false;
                } else if (hotel[i][j].klient.equals(os)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void zwolnijZajetePrzez(Osoba os) {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if ((hotel[i][j].klient).equals(os)) {
                    hotel[i][j].klient = null;
                }
            }
        }
    }

    public void listaWolnychPokoi() {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                if (hotel[i][j].czyWolnyPokoj() == true) {
                    System.out.println(hotel[i][j].numer);
                }
            }

        }
    }



    public void listaGosci() {
        for (int i = 1; i < hotel.length; i++) {
            for (int j = 0; j < hotel[i].length; j++) {
                System.out.println(hotel[i][j].toString()+" "+hotel[i][j].getNumer());
            }
        }
    }
}

