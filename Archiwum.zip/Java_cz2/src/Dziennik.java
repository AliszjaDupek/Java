import java.util.Scanner;
public class Dziennik {
    int liczbaUczniow;
    String wychowawca;
    int[] ocenyKR = new int[liczbaUczniow];
    String symbol;

    //Konstruktory
    // - domyślny
    public Dziennik() {
        liczbaUczniow = 32;
        wychowawca = "Danuta Gierczak";
        ocenyKR = new int[]{3, 4, 5, 6, 3, 4, 6, 3, 2, 4, 5, 3, 4, 6, 6, 5, 4, 5, 6, 3, 4, 5, 5, 6, 4, 3, 5, 6, 4, 3, 6, 6};
        symbol = "1E";
    }

    // - przeciążony
    public Dziennik(int liczbaUczniow, String wychowawca, int[] ocenyKR, String symbol) {
        this.liczbaUczniow = liczbaUczniow;
        this.ocenyKR = ocenyKR;
        this.wychowawca = wychowawca;
        this.symbol = symbol;
    }

    //SET
    public void setLiczbaUczniow(int liczbaUczniow) {
        this.liczbaUczniow = liczbaUczniow;
    }

    public void setOcenyKR(int[] ocenyKR) {
        this.ocenyKR = ocenyKR;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setWychowawca(String wychowawca) {
        this.wychowawca = wychowawca;
    }

    //GET
    public int getLiczbaUczniow() {
        return liczbaUczniow;
    }

    public int[] getOcenyKR() {
        return ocenyKR;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getWychowawca() {
        return wychowawca;
    }

    public int[] dodajOcene(int index, int ocena) {
        if (ocena > 6 || ocena < 1) {
            System.out.println("Taka ocena nie istnieje, podaj inną ocenę");
        }
        if (getOcenyKR().length - 1 > index || index < 0) {
            System.out.println("Index wychodzi poza liczbe ocen, podaj inny index :");
        }
        getOcenyKR()[index] = ocena;
        return getOcenyKR();
    }

    public void wyswietlOceny() {
        for (int liczba : getOcenyKR()) {
            System.out.print(liczba + " ");
        }
        System.out.println();
    }

    public String toString() {
        return "Klasa " + symbol + " :" + "\n -Liczba uczniów = " + liczbaUczniow + "\n -Wychowawca = " + wychowawca;
    }

    public int[] usunOcene(int index) {
        if (ocenyKR.length-1<index || index < 0) {
            System.out.println("Index wychodzi poza liczbe ocen, podaj inny index :");
        }
        else {
            ocenyKR[index] = -1;
        }
        return ocenyKR;
    }

    public int[] podwyzszOcene(int index) {
        if ((ocenyKR.length-1<index) || (index < 0)) {
            System.out.println("Index wychodzi poza ilosc liczb, podaj inny index");
        }
        if (ocenyKR[index] > 6 || ocenyKR[index] < 0) {
            System.out.println("Nie istnieje taka ocena, podaj inną ocenę");
        }
        ocenyKR[index] = ocenyKR[index] + 1;
        return ocenyKR;
    }
}