import java.util.Random;
public class Tablica {
    public static void main(String[] args){
        int [] tab = new int[10];
        wyswietlTabInt(StworzTab(tab));
        sumaTab(tab);
    }
    public static int[] StworzTab(int[] tablica){
        Random random = new Random();
        for (int i=0; i<tablica.length; i++){
            tablica[i]=random.nextInt(1,100);
        }
        return tablica;
    }
    public static void wyswietlTabInt(int[] tablica) {
        for (int liczba : tablica) {
            System.out.print(liczba + " ");}
        System.out.println("");
    }
    public static void sumaTab(int[] tablica){
        int suma=0;
        for(int i: tablica){
            suma+=i;
        }
        System.out.println("Suma: "+suma);
    }

}

