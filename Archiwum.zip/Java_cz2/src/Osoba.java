public class Osoba {
    //Pola klasy
    int wiek;
    double wzrost;
    String imie;

    //Konstruktory
    //Konstruktor domyślny

    public Osoba(){
       wiek=19;
       wzrost=155.4;
       imie="Jan";
    }
    //Konstruktory przeciążone
    public Osoba(int wiek, double wzrost, String imie){
        this.wiek=wiek;
        this.wzrost=wzrost;
        this.imie=imie;
    }
    public Osoba(String imie, int wiek){
        this.wiek=wiek;
        this.imie=imie;
    }

    //Metody
    //Set
    public void setWiek(int wiek){
        this.wiek=wiek;
    }
    public void setWzrost(double wzrost){
        this.wzrost=wzrost;
    }
    public void setImie(String imie){
        this.imie=imie;
    }
    //Get
    public int getWiek(){
        return wiek;
    }
    public double getWzrost(){
        return wzrost;
    }
    public String getImie(){
        return imie;
    }

    public void wyswietlPola(){
        System.out.println("Imie: "+imie+"\nWiek: "+wiek+"\nWzrost: "+wzrost);
        System.out.println();
    }

    public String toString() {
        return "Osoba: "+"\n Imie = "+imie+"\n Wiek = "+wiek+"\n Wzrost = "+wzrost+"\n";
    }
    public boolean equals(Osoba obj) {
        if (imie.equals(obj.getImie()) && wiek == obj.getWiek() && wzrost == getWzrost()) {
            return true;
        }
        return false;
    }




}
