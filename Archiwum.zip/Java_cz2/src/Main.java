import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
//        Random generator = new Random();
//        int [] tab = new int[10];
//        double [] tablica = new double[10];
//        for(int i=0; i<tab.length;i++){
//            tab[i] = generator.nextInt(0,50);
//        }
//        for(int i=0; i<tab.length; i++){
//            tablica[i]=generator.nextDouble(0,50);
//        }
//        wyswietlTabInt(tab);
//        wyswietlTabDob(tablica);
//    }
//    public static void wyswietlTabInt(int[] tablica){
//        for(int liczba: tablica){
//            System.out.print(liczba+" ");}
//        System.out.println("");
//    }
//
//    public static void wyswietlTabDob(double[] tab){
//        for(double liczba: tab){
//            System.out.format("%.2f%n",liczba);}
//        System.out.println("");
//    }
//
//    public static void wyswietlOdTylu(float[] tablica){
//        for(int i=tablica.length-1; i>=0; i--){
//            System.out.print(tablica[i]+" ");}
//        System.out.println("");
//    }
/*
    Osoba osoba1 = new Osoba();
    osoba1.wyswietlPola();
        System.out.println();
    Osoba osoba2 = new Osoba(14,170,"Alicja");
    osoba2.wyswietlPola();
        System.out.println();
    Osoba osoba3 = new Osoba("Michalina",14);
    osoba3.wyswietlPola();
    System.out.println();
    System.out.println(osoba1.getImie()+","+osoba1.getWiek());

        System.out.println(osoba1.toString());
        System.out.println(osoba2.toString());
        System.out.println(osoba3.toString());

        Osoba osoba4 = new Osoba();
        System.out.println(osoba1.equals(osoba2));
        System.out.println(osoba1.equals(osoba4));

 */
        Random generator = new Random();
        int[] ocenki = new int[30];
        Dziennik klasa1 = new Dziennik(30, "Alicja Dudek",ocenki,"1B");
        System.out.println(klasa1.toString());
        klasa1.wyswietlOceny();
        Dziennik klasa2 = new Dziennik();
        klasa2.setLiczbaUczniow(34);
        System.out.println(klasa2.toString());
        klasa2.wyswietlOceny();
        klasa1.dodajOcene(3,6);
        klasa1.wyswietlOceny();
        klasa1.usunOcene(3);
        klasa1.wyswietlOceny();
        klasa1.podwyzszOcene(3);
    }
}