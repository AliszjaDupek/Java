import java.util.Random;
public class Matryce {
    public static void main(String[] args){
     int[][] macierz = new int[2][3];
     wyswietlMat(StworzMat(macierz));
    }

    public static int[][] StworzMat(int[][] macierz){
        Random generator = new Random();
        for(int i=0; i<macierz.length; i++){
            for(int j=0; j< macierz[i].length; j++){
                macierz[i][j]=generator.nextInt(0,10);
            }
        }
        return macierz;
    }

    public static void wyswietlMat(int[][] macierz){
        for (int i=0; i<macierz.length; i++){
            for(int j=0; j<macierz[i].length;j++){
                System.out.print(macierz[i][j]+" ");
            }
            System.out.println("");
        }
    }

}
