import java.util.Random;
import java.util.Scanner;
public class ZgadnijLiczbe {
    public static void main(String[] args){
        CzyMniejszaWieksza(liczba());
    }
    public static int liczba(){
        Random generator = new Random();
        int liczba=generator.nextInt(1,100);
        return liczba;
    }

    public static void CzyMniejszaWieksza(int liczba){
        Scanner scanner = new Scanner(System.in);
        int liczbaProb=1;
        int podajLiczbe=0;
        while(podajLiczbe!=liczba) {
            System.out.println("Podaj Liczbe");
            podajLiczbe = scanner.nextInt();
            if (podajLiczbe>liczba){
                System.out.println("Liczba jest za duża");
                liczbaProb++;
            }
            if (podajLiczbe<liczba){
                System.out.println("Liczba jest za mała");
                liczbaProb++;
            }
            if (podajLiczbe==liczba){
                System.out.println("Wygrałeś!"+" Liczba : "+liczba);
                System.out.println("Liczba prób : "+ liczbaProb);
                break;
            }
        }
    }


}
