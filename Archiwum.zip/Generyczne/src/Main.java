import java.lang.reflect.Array;
import java.util.*;

public class Main {
    public static void main(String[] args) {
//        List<Klasa> lista = new ArrayList<>();
        Klasa k1 = new Klasa("VA","Mikołaj Nowak");
        Klasa k2 = new Klasa("VIIB", "Jan Kowalski");
//        lista.add(k1);
//        lista.add(k2);
//        wyswietl(lista);
//        System.out.println(lista.contains(k1));
//        System.out.println(lista.size());
//        System.out.println(lista.isEmpty());
//        lista.remove(k1);
//        System.out.println(lista.contains(k1));
//        System.out.println(lista.size());
//        System.out.println(lista.isEmpty());
//        lista.clear();
//        System.out.println(lista.isEmpty());
//        Set <Klasa> set = new HashSet<Klasa>();
//        set.add(k1);
//        set.add(k2);
//        set.add(k1);
//        wyswietlPetla(set);
//        System.out.println(set.contains(k1));
//        System.out.println(set.size());
//        System.out.println(set.remove(k1));
//        wyswietlIterator(set);

        Map <Integer,Klasa> klasy = new HashMap<>();
        klasy.put(1,k1);
        klasy.put(2,k2);

        Set<Map.Entry<Integer,Klasa>> entries = klasy.entrySet();
        for(Map.Entry<Integer,Klasa> entry: entries){
            System.out.println(entry.getKey()+ " "+ entry.getValue());
        }
        System.out.println(klasy.get(1));
        System.out.println(klasy.containsValue(k1));
        System.out.println(klasy.containsKey(3));
        System.out.println(klasy.size());
    }
    public static void wyswietlPetla(Set<Klasa> set){
        for(Klasa k: set) {
            System.out.println(k.toString());
        }
    }

    public static void wyswietlIterator(Set<Klasa> set){
        Iterator <Klasa> iterator = set.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next().toString());
        }
    }

    public static void wyswietl(List<Klasa> lista){
        for(int i=0; i<lista.size(); i++){
            System.out.println(lista.get(i).toString());
        }
    }

}