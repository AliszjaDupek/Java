package ZadanieNaStart;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main{
    public static void main(String[] args) {
        List<Klasa> lista = new ArrayList<>();
        Klasa k1 = new Klasa();
        Klasa k2 = new Klasa(2,"Jan Kowalski");
        Klasa k3 = new Klasa(3,"Danuta Gierczak");

        lista.add(k1);
        lista.add(k2);
        lista.add(k3);
        wyswietl(lista);
        System.out.println("-----------");
        lista.remove(k2);
        wyswietl(lista);
        System.out.println("-----------");
        Collections.reverse(lista);
        wyswietl(lista);
    }
    public static void wyswietl(List<Klasa> lista) {
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i).toString());
        }
    }

    public static int compareTo(List<Klasa> lista) {
        int najw=0;
        for(int i=0; i<lista.size(); i++){
            if (lista.get(i).symbol>najw){
                najw=lista.get(i).symbol;
            }
            lista.remove(najw);
            for(int j=0; j<lista.size();j++){
                if (lista.get(j).symbol>najw) {
                    najw = lista.get(j).symbol;
                }
            }
        }
        return najw;
    }
    public static List<Klasa> odwroc(List<Klasa> lista){
        List<Klasa> lista2 = new ArrayList<>();
        for(int i=lista.size(); i>0; i--){
            lista2.add(lista.get(i));
        }
        return lista2;
    }

}
