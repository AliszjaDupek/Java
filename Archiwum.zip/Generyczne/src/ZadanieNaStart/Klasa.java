package ZadanieNaStart;
import java.util.List;
public class Klasa{
    protected int symbol;
    protected String wychowawca;

    public Klasa(){
        symbol=1;
        wychowawca="Jan Kowalski";
    }

    public Klasa(int symbol, String wychowawca){
        this.symbol=symbol;
        this.wychowawca=wychowawca;
    }

    public String toString() {
        return symbol+" "+wychowawca;
    }


}

