import java.util.Objects;

public class Klasa {
    private String symbol;
    private String wychowawca;

    public Klasa(){
        symbol="VA";
        wychowawca="Jan Kowalski";
    }

    public Klasa(String symbol, String wychowawca){
        this.symbol=symbol;
        this.wychowawca=wychowawca;
    }

    @Override
    public String toString() {
        return symbol + " " + wychowawca;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Klasa klasa = (Klasa) o;
        return symbol.equals(klasa.symbol) && wychowawca.equals(klasa.wychowawca);
    }

    @Override
    public int hashCode() {
        return Objects.hash(symbol, wychowawca);
    }
}
