package KółkoKrzyżyk;

public class Main {
    public static void main(String[] args) {
        Gra gra = new Gra();

    }
}
