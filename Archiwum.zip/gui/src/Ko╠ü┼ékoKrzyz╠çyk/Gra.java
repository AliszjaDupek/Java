package KółkoKrzyżyk;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


public class Gra extends JFrame implements ActionListener {
    JLabel label;
    int kolejGracza;
    JPanel panel;
    JButton [] buttons;
    JButton l1;
    JButton l2;
    JButton l3;
    JButton l4;
    JButton l5;
    JButton l6;
    JButton l7;
    JButton l8;
    JButton l9;

    JButton graj;

    public Gra(){
        this.setSize(210,300);
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
    //buttons
        buttons = new JButton[9];
        l1 = new JButton();
        l2 = new JButton();
        l3 = new JButton();
        l4 = new JButton();
        l5 = new JButton();
        l6 = new JButton();
        l7 = new JButton();
        l8 = new JButton();
        l9 = new JButton();

        buttons[0]=l1;
        buttons[1]=l2;
        buttons[2]=l3;
        buttons[3]=l4;
        buttons[4]=l5;
        buttons[5]=l6;
        buttons[6]=l7;
        buttons[7]=l8;
        buttons[8]=l9;

        for(int i=0; i<9; i++){
            buttons[i].setSize(50,50);
            buttons[i].addActionListener(this);
            buttons[i].setEnabled(false);
            buttons[i].setFont(new Font("Italic", Font.BOLD, 40));
        }

        panel = new JPanel();
        panel.setBounds(10,50,190,190);
        panel.setLayout(new GridLayout(3,3,10,10));

        for(int i=0; i<9; i++){
            panel.add(buttons[i]);
        }
        //label
        label = new JLabel("Kółko i Krzyżyk");
        label.setBounds(10,5,190,30);
        //graj - button
        graj = new JButton("\uD83C\uDFB2");
        graj.setBounds(170,10,20,20);
        graj.addActionListener(this);

        this.add(graj);
        this.add(label);
        this.add(panel);
        this.setVisible(true);


    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==graj){
            Random random = new Random();

            kolejGracza = random.nextInt(0,2);
            if(kolejGracza==0){
                label.setText("Kolej : o");
            }
            else {
                label.setText("Kolej : x");
            }
            for(int i=0; i<9;i++){
                buttons[i].setEnabled(true);
            }
            graj.setEnabled(false);

        }
        if(e.getSource()==l1){
            if(!l1.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l1.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l1.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l2){
            if(!l2.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l2.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l2.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l3){
            if(!l3.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l3.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l3.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l4){
            if(!l4.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l4.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l4.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l5){
            if(!l5.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l5.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l5.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l6){
            if(!l6.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l6.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l6.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l7){
            if(!l7.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l7.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l7.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l8){
            if(!l8.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l8.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l8.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }
        if(e.getSource()==l9){
            if(!l9.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Pole zajete","UWAGA",JOptionPane.WARNING_MESSAGE);
            }
            else {
                if(kolejGracza==0){
                    l9.setText("o");
                    kolejGracza=1;
                    label.setText("Kolej gracza : x");
                }
                else{
                    l9.setText("x");
                    kolejGracza=0;
                    label.setText("Kolej gracza : o");
                }
            }
            sprawdz();
        }


    }
    public void sprawdz(){
        if(l1.getText().equals("x") && l5.getText().equals("x") && l9.getText().equals("x")){
            l1.setForeground(new Color(0xFF7E7E));
            l5.setForeground(new Color(0xFF7E7E));
            l9.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l1.getText().equals("o") && l5.getText().equals("o") && l9.getText().equals("o")){
            l1.setForeground(new Color(0xFF7E7E));
            l5.setForeground(new Color(0xFF7E7E));
            l9.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l3.getText().equals("x") && l5.getText().equals("x") && l7.getText().equals("x")){
            l3.setForeground(new Color(0xFF7E7E));
            l5.setForeground(new Color(0xFF7E7E));
            l7.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l3.getText().equals("o") && l5.getText().equals("o") && l7.getText().equals("o")){
            l3.setForeground(new Color(0xFF7E7E));
            l5.setForeground(new Color(0xFF7E7E));
            l7.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l1.getText().equals("x") && l2.getText().equals("x") && l3.getText().equals("x")){
            l1.setForeground(new Color(0xFF7E7E));
            l2.setForeground(new Color(0xFF7E7E));
            l3.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l1.getText().equals("o") && l2.getText().equals("o") && l3.getText().equals("o")){
            l1.setForeground(new Color(0xFF7E7E));
            l2.setForeground(new Color(0xFF7E7E));
            l3.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l1.getText().equals("x") && l4.getText().equals("x") && l7.getText().equals("x")){
            l1.setForeground(new Color(0xFF7E7E));
            l4.setForeground(new Color(0xFF7E7E));
            l7.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l1.getText().equals("o") && l4.getText().equals("o") && l7.getText().equals("o")){
            l1.setForeground(new Color(0xFF7E7E));
            l4.setForeground(new Color(0xFF7E7E));
            l7.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l7.getText().equals("x") && l8.getText().equals("x") && l9.getText().equals("x")){
            l7.setForeground(new Color(0xFF7E7E));
            l8.setForeground(new Color(0xFF7E7E));
            l9.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l7.getText().equals("o") && l8.getText().equals("o") && l9.getText().equals("o")){
            l7.setForeground(new Color(0xFF7E7E));
            l8.setForeground(new Color(0xFF7E7E));
            l9.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l9.getText().equals("x") && l6.getText().equals("x") && l3.getText().equals("x")){
            l9.setForeground(new Color(0xFF7E7E));
            l6.setForeground(new Color(0xFF7E7E));
            l3.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały x!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(l9.getText().equals("o") && l6.getText().equals("o") && l3.getText().equals("o")){
            l9.setForeground(new Color(0xFF7E7E));
            l6.setForeground(new Color(0xFF7E7E));
            l3.setForeground(new Color(0xFF7E7E));
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Wygrały o!","Koniec gry", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if(!l1.getText().equals("") && !l2.getText().equals("") && !l3.getText().equals("") && !l4.getText().equals("") && !l5.getText().equals("") && !l6.getText().equals("") && !l7.getText().equals("") && !l8.getText().equals("") && !l9.getText().equals("")){
            label.setText("Koniec gry!");
            JOptionPane.showMessageDialog(null,"Remis!","Koniec gry",JOptionPane.INFORMATION_MESSAGE);
        }

    }

}
