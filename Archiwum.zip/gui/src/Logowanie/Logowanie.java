package Logowanie;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Logowanie extends JFrame implements ActionListener, KeyListener {

    JMenuBar menu;
    JMenu file;
    JMenu edit;
    JMenu load;
    JMenuItem exit;
    JMenuItem help;
    JLabel labelLogin;
    JLabel labelHaslo;
    JTextField login;
    JPasswordField haslo;
    JButton zaloguj;
    JLabel nplogin;
    Map<String,String> mapa = new HashMap<>();
    public Logowanie(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(500,300);
        this.getContentPane().setBackground(new Color(0x1B356A));
        this.setLayout(null);
        //mapa
        mapa.put("ms200","1a3");
        mapa.put("Alicja","12345");


        //menu
        menu = new JMenuBar();
        file = new JMenu("File");
        edit = new JMenu("Edit");
        load = new JMenu("Load");
        exit = new JMenuItem("exit");
        help = new JMenuItem("help");

        menu.add(file);
        menu.add(edit);
        menu.add(load);
        file.add(exit);
        file.add(help);
        exit.addActionListener(this);
        help.addActionListener(this);

        //label
        labelLogin = new JLabel("Podaj login :");
        labelLogin.setBounds(200,5,400,100);
        labelLogin.setFont(new Font("Times New Roman",Font.BOLD,20));
        labelHaslo = new JLabel("Podaj hasło :");
        labelHaslo.setBounds(200,90,400,100);
        labelHaslo.setFont((new Font("Times New Roman",Font.BOLD,20)));
        nplogin = new JLabel("Niepoprawny login lub haslo");
        nplogin.setFont(new Font("Times New Roman",Font.PLAIN,10));
        nplogin.setForeground(Color.red);
        nplogin.setBounds(100,110,300,10);
        nplogin.setVisible(false);
        //TextField
        login = new JTextField();
        login.setBounds(100,75,300,30);

        haslo = new JPasswordField();
        haslo.setBounds(100,160,300,30);
        //button
        zaloguj = new JButton("ZALOGUJ");
        zaloguj.setBounds(200,200,100,30);
        zaloguj.addActionListener(this);
        haslo.addKeyListener(this);


        this.add(nplogin);
        this.add(zaloguj);
        this.add(haslo);
        this.add(labelHaslo);
        this.add(login);
        this.setJMenuBar(menu);
        this.add(menu);
        this.add(labelLogin);

        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == exit){
            System.exit(0);
        }
        if(e.getSource() == help){
            JOptionPane.showMessageDialog(null,"Instrukcja :","Help", JOptionPane.PLAIN_MESSAGE);
        }
        if(e.getSource() == zaloguj){
            char [] tab = haslo.getPassword();
            Set<Map.Entry<String,String>> set = mapa.entrySet();
            for(Map.Entry<String,String>entity:set){
                if(entity.getKey().equals(login.getText()) && entity.getValue().equals(String.valueOf(tab))){
                    nplogin.setVisible(false);
                    Zalogowane zalogowane = new Zalogowane(login.getText());
                    this.setVisible(false);
                }
            nplogin.setVisible(true);
            }
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(String.valueOf(e.getKeyChar()).equals("\n")){
            zaloguj.doClick();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
