package Logowanie;

import javax.swing.*;
import java.awt.*;

public class Zalogowane extends JFrame {
    JLabel label;

    public Zalogowane(String login){
        this.setSize(300,100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setLayout(null);
        this.getContentPane().setBackground(Color.BLACK);


        label = new JLabel("Hello! "+login);
        label.setFont(new Font("Times new Roman",Font.BOLD,15));
        label.setForeground(Color.white);
        label.setBounds(10,10,300,50);

        this.add(label);
        this.setVisible(true);
    }

}
