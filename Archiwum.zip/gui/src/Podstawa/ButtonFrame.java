package Podstawa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonFrame extends JFrame implements ActionListener {
    JLabel label;
    JButton button;


    public ButtonFrame(){
        label= new JLabel();
        label.setText("Hello World!");
        label.setBounds(300,300,250,250);

        button = new JButton();
        button.setText("KLIKNIJ");
        button.setBounds(0,0,100,100);
        button.addActionListener(this);

        this.setTitle("Moja ramka");
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(700, 700);
        this.getContentPane().setBackground(new Color(0x1B356A));
        this.add(label);
        this.add(button);

        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button){
            this.dispose();
            MojaRamka ramka = new MojaRamka();
            System.out.println("Klikam przycisk");
        }
    }
}
