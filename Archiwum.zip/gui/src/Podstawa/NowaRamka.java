package Podstawa;

import javax.swing.*;
import java.awt.*;

public class NowaRamka extends JFrame {
    JLabel label;
    JPanel bluePanel;
    JPanel blackPanel;
    JPanel whitePanel;
    public NowaRamka() {
        label= new JLabel();
        label.setText("Hello World!");
        ImageIcon icon = new ImageIcon(new ImageIcon("src/p.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
        label.setIcon(icon);
        label.setVerticalAlignment(JLabel.BOTTOM);
        label.setHorizontalAlignment(JLabel.RIGHT);
        label.setBounds(20,20,170,90);

        bluePanel = new JPanel();
        bluePanel.setBackground(Color.BLUE);
        bluePanel.setBounds(0,0,200,200);
        bluePanel.setLayout(null);

        blackPanel= new JPanel();
        blackPanel.setBackground(Color.BLACK);
        blackPanel.setBounds(200,0,200,200);
        blackPanel.setLayout(null);

        whitePanel = new JPanel();
        whitePanel.setBackground(Color.WHITE);
        whitePanel.setLayout(null);
        whitePanel.setBounds(0,200,400,400);

        this.setTitle("Moja ramka");
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(700, 700);
        this.getContentPane().setBackground(new Color(0x1B356A));
        this.add(label);
        this.setIconImage(icon.getImage());
        this.add(bluePanel);
        this.add(blackPanel);
        this.add(whitePanel);
        this.setVisible(true);
    }
}
