package Podstawa;

import javax.swing.*;
import java.awt.*;

public class Grid {
    public static void main(String[] args){
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(new GridLayout(2,2,10,10));

        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton b4 = new JButton("4");
        frame.add(b1);
        frame.add(b2);
        frame.add(b3);
        frame.add(b4);
//        frame.setVisible(true);
    }
}
