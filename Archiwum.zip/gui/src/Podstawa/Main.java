package Podstawa;

import javax.swing.*;

public class Main {
    public static void main(String[] args){
//        JFrame frame = new JFrame();
//        frame.setTitle("Moja pierwsza ramka");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(300,300);
//        frame.setResizable(false);
//        frame.setVisible(true);
//        ButtonFrame rm = new ButtonFrame();

        //JOptionPane.showMessageDialog(null,"This is info","Tytuł okna", JOptionPane.INFORMATION_MESSAGE);
//        int odpowiedz = JOptionPane.showConfirmDialog(null,"Czy chcesz kontynuowac","Pytanie",JOptionPane.YES_NO_CANCEL_OPTION);
//        if (odpowiedz==0){
//            System.out.println("Zgodziles sie");
//        }
//        String name = JOptionPane.showInputDialog("Podaj swoje imie");
//        System.out.println("Cześć "+name);
        MojaRamka mojaRamka = new MojaRamka();

    }
}
