package Podstawa;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MojaRamka extends JFrame implements ActionListener {
    JLabel label;
    JButton button;
    JPasswordField passwordField;
    public MojaRamka(){
        label= new JLabel();
        label.setText("Hello World!");
        label.setForeground(new Color(0x99AED8));
        label.setFont(new Font("Times New Roman", Font.BOLD,30));
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.TOP);
        label.setBackground(new Color(0x4A68A5));
        label.setOpaque(true);
        label.setBounds(0,0,300,100);

        button = new JButton("submit");
        button.setBounds(100,100,120,20);
        button.addActionListener(this);
        passwordField=new JPasswordField();
        passwordField.setBounds(100,150,120,30);

        this.add(passwordField);
        this.add(button);
        this.setTitle("Moja ramka");
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(300,300);
        this.getContentPane().setBackground(new Color(0x1B356A));
        ImageIcon icon = new ImageIcon(new ImageIcon("src/p.png").getImage().getScaledInstance(50,50,Image.SCALE_DEFAULT));
        label.setIcon(icon);

        this.setIconImage(icon.getImage());


        this.add(label);
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == button){
            char [] input = passwordField.getPassword();
            System.out.println(input);
            System.out.println(input.getClass());
            String password = String.valueOf(input);
            System.out.println(password);

        }
    }
}
