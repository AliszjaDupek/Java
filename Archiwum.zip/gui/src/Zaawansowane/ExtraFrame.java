package Zaawansowane;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class ExtraFrame extends JFrame implements ActionListener, ChangeListener {
    JCheckBox checkBox;
    JButton submitButton;
    JRadioButton pizzaButton;
    JRadioButton burgerButton;
    JRadioButton makaronButton;
    JSlider slider;
    JLabel temperatura;
    JPanel sliderPanel;
    JComboBox<String> comboBox;
    JProgressBar progressBar;
    JButton wybierzKolor;
    JLabel napisKolor;
    JMenuBar menuBar;
    JMenu fileMenu;
    JMenu helpMenu;
    JMenuItem exitMenu;
    JMenuItem saveMenu;



    public ExtraFrame(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);

        //Inicjalizacja checkboxa
        checkBox = new JCheckBox("Nie jestem robotem");
        checkBox.setFocusable(false);
        checkBox.setFont(new Font("Consolas", Font.PLAIN, 20));
        checkBox.setBounds(20,10,250,50);

        submitButton = new JButton("Potwierdz");
        submitButton.addActionListener(this);
        submitButton.setFocusable(false);
        submitButton.setBounds(300,10,100,50);

        //Inicjalizacja RadioButton
        pizzaButton = new JRadioButton("Pizza");
        burgerButton = new JRadioButton("Burger");
        makaronButton = new JRadioButton("Makaron");

        pizzaButton.addActionListener(this);
        burgerButton.addActionListener(this);
        makaronButton.addActionListener(this);

        pizzaButton.setBounds(50,100,100,50);
        burgerButton.setBounds(180,100,100,50);
        makaronButton.setBounds(290,100,100,50);

        ButtonGroup group = new ButtonGroup();
        group.add(pizzaButton);
        group.add(burgerButton);
        group.add(makaronButton);

        //Inicjalizacja slidera
        slider = new JSlider(0,100,50);
        sliderPanel = new JPanel();
        temperatura = new JLabel();

        sliderPanel.setBounds(30,250,100,250);
        slider.setPreferredSize(new Dimension(200,200));
        slider.setOrientation(SwingConstants.VERTICAL);
        slider.setPaintTicks(true);
        slider.setMajorTickSpacing(25);
        slider.setPaintLabels(true);

        temperatura.setText("C = " + slider.getValue());
        slider.addChangeListener(this);

        sliderPanel.add(slider);
        sliderPanel.add(temperatura);

        //Inicjalizacja comboBox
        String[] zwierzeta = {"kotek", "chomik", "jaszczur"};
        comboBox=new JComboBox<>(zwierzeta);
        comboBox.addItem("pies");
        comboBox.insertItemAt("kon",0);
        comboBox.setSelectedIndex(0);
        comboBox.setBounds(260,300,200,50);

        //Inicjalizacja progressBar
        progressBar = new JProgressBar(0,100);
        progressBar.setBounds(40,530,400,50);
        progressBar.setBackground(Color.blue);
        progressBar.setOpaque(true);
        progressBar.setForeground(Color.white);
        progressBar.setValue(100);
        progressBar.setStringPainted(true);

        //Inicjalizacja kolor chooser
        wybierzKolor = new JButton("Wybierz kolor");
        wybierzKolor.addActionListener(this);
        wybierzKolor.setBounds(250,600,200,50);
        napisKolor = new JLabel();
        napisKolor.setBackground(Color.PINK);
        napisKolor.setOpaque(true);
        napisKolor.setText("To jest mój wybrany kolor");
        napisKolor.setBounds(30,600,200,100);

        //Inicjalizacja menu Bara
        menuBar = new JMenuBar();
        fileMenu = new JMenu("File");
        helpMenu = new JMenu("Help");
        saveMenu = new JMenu("Save");
        exitMenu = new JMenu("Exit");

        saveMenu.addActionListener(this);
        exitMenu.addActionListener(this);

        fileMenu.add(saveMenu);
        fileMenu.add(exitMenu);

        menuBar.add(fileMenu);
        menuBar.add(helpMenu);

        fileMenu.setMnemonic(KeyEvent.VK_F);
        saveMenu.setMnemonic(KeyEvent.VK_S);
        exitMenu.setMnemonic(KeyEvent.VK_E);

        this.setJMenuBar(menuBar);
        this.add(menuBar);
        this.add(wybierzKolor);
        this.add(napisKolor);
        this.add(progressBar);
        this.add(comboBox);
        this.add(sliderPanel);
        this.add(checkBox);
        this.add(submitButton);
        this.add(pizzaButton);
        this.add(burgerButton);
        this.add(makaronButton);

        this.setVisible(true);

        odliczaj();
    }


    public void odliczaj(){
        int counter = 100;
        while(counter>0){
            progressBar.setValue(counter);
            try{
                Thread.sleep(50);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            counter--;
        }
        progressBar.setString("Pobrano");
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == submitButton){
            System.out.println(checkBox.isSelected());
        }
        if(e.getSource() == wybierzKolor){
            JColorChooser colorChooser= new JColorChooser();
            Color color = JColorChooser.showDialog(null,"Wybierz kolor: ",Color.BLACK);
            napisKolor.setBackground(color);
        }

        if(e.getSource() == exitMenu){
            System.exit(0);
        }
        if(e.getSource() == saveMenu){
            JOptionPane.showMessageDialog(null,"Plik został zapisany");
        }

    }
    @Override
    public void stateChanged(ChangeEvent e) {
        temperatura.setText("C = "+ slider.getValue());
    }
}
