package Zaawansowane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class MouseListener extends JFrame implements java.awt.event.MouseListener {
    JLabel label;
    public MouseListener(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);

        label = new JLabel();
        label.setBounds(10,10,200,300);
        label.setOpaque(true);
        label.setBackground(Color.PINK);
        label.addMouseListener(this);

        this.add(label);
        this.setVisible(true);

        this.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        System.out.println("Naciskasz i pusciles");
    }

    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("Naciskasz");
        label.setBackground(Color.yellow);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        System.out.println("Puszczasz");
        label.setBackground(Color.gray);
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        System.out.println("Najechales myszka");
        label.setBackground(Color.magenta);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        System.out.println("Kursor uciekl");
        label.setBackground(Color.pink);
    }
}
