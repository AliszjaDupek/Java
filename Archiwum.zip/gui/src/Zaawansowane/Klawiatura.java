package Zaawansowane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Klawiatura extends JFrame implements KeyListener {
    JLabel label;
    ImageIcon icon;
    public Klawiatura(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500,800);
        this.setLayout(null);
        this.getContentPane().setBackground(Color.orange);


        label=new JLabel();
        label.setBounds(0,0,100,100);
        label.setBackground(Color.orange);
        icon=new ImageIcon(new ImageIcon("src/p.png").getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
        label.setIcon(icon);
        label.setOpaque(true);
        this.addKeyListener(this);
        this.add(label);
        this.setVisible(true);





        this.setVisible(true);

    }





    @Override
    public void keyTyped(KeyEvent e) {

    }
    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyChar()){
            case 'a' -> label.setLocation(label.getX()-10, label.getY());
            case 'd' -> label.setLocation(label.getX()+10, label.getY());
            case 'w' -> label.setLocation(label.getX(), label.getY()-10);
            case 's' -> label.setLocation(label.getX(), label.getY()+10);

        }
    }
    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println("Naciskasz: "+ e.getKeyChar());
        System.out.println("Naciskasz przycisk o kodzie: " + e.getKeyCode());
    }
}
