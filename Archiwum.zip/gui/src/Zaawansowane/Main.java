package Zaawansowane;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Main {
    public static void main(String[] args){
//        ExtraFrame frame = new ExtraFrame();
//        MouseListener mouseListener = new MouseListener();
        Klawiatura klawiatura = new Klawiatura();
    }
}
