package Arkusz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Arkusz extends JFrame implements ActionListener {
    JLabel napis;
    JButton potw;
    JMenuBar menuBar;
    JComboBox<String> profil;
    JButton submitButton;
    JRadioButton I;
    JRadioButton II;
    JRadioButton III;
    JRadioButton IV;
    JTextField panelNazw;
    JTextField panelImie;
    JLabel ln;
    JLabel li;
    JMenuItem exit;
    JLabel label;
    JLabel lI;
    JLabel lII;
    JLabel lIII;
    JLabel lIV;
    JLabel klasa;
    public String imie;
    public String nazwisko;

    public Arkusz(){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500, 700);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(0x6E8FD1));

        //MenuBar
        menuBar = new JMenuBar();
        exit = new JMenuItem("EXIT");
        exit.addActionListener(this);
        menuBar.setName("Arkusz");
        menuBar.add(exit);
        //label
        label = new JLabel("Arkusz");
        label.setBounds(210,5,400,100);
        label.setFont(new Font("Times New Roman",Font.PLAIN,20));
        napis = new JLabel();
        napis.setBounds(50,400,100,50);

        li = new JLabel("Podaj imię: ");
        li.setBounds(20,100,150,50);
        li.setFont(new Font("Times New Roman", Font.BOLD,20));
        ln = new JLabel("Podaj nazwisko: ");
        ln.setBounds(20,150,150,50);
        ln.setFont(new Font("Times New Roman", Font.BOLD,20));
        klasa = new JLabel("Wybierz klasę: ");
        klasa.setBounds(20,190,150,100);
        klasa.setFont(new Font("Times New Roman", Font.BOLD,17));

        lI = new JLabel("I");
        lI.setBounds(160,210,100,50);
        lII = new JLabel("II");
        lII.setBounds(256,210,100,50);
        lIII = new JLabel("III");
        lIII.setBounds(351,210,100,50);
        lIV = new JLabel("IV");
        lIV.setBounds(455,210,100,50);
        lI.setFont(new Font("Times New Roman", Font.BOLD,20));
        lII.setFont(new Font("Times New Roman", Font.BOLD,20));
        lIII.setFont(new Font("Times New Roman", Font.BOLD,20));
        lIV.setFont(new Font("Times New Roman", Font.BOLD,20));


        //TextField
        panelImie = new JTextField();
        panelNazw = new JTextField();
        panelImie.setBounds(170,100,300,50);
        panelNazw.setBounds(170,150,300,50);


        //RadioButtons
        I = new JRadioButton();
        II = new JRadioButton();
        III = new JRadioButton();
        IV = new JRadioButton();

        I.setBounds(150,200,100,100);
        II.setBounds(250,200,100,100);
        III.setBounds(350,200,100,100);
        IV.setBounds(450,200,100,100);
        //CheckBox
        profil = new JComboBox<>();
        profil.addItem("matfiz");
        profil.addItem("biolchem");
        profil.addItem("matgeo");
        profil.addItem("matinf");
        profil.setBounds(200,250,250,100);

        //JButton
        potw = new JButton("Zatwierdź");
        potw.setBounds(150,400,200,50);
        potw.addActionListener(this);

        this.add(potw);
        this.add(profil);
        this.add(lI);
        this.add(lII);
        this.add(lIII);
        this.add(lIV);
        this.add(klasa);
        this.add(I);
        this.add(II);
        this.add(III);
        this.add(IV);
        this.add(ln);
        this.add(li);
        this.add(panelNazw);
        this.add(panelImie);
        this.setJMenuBar(menuBar);
        this.add(label);

        this.setVisible(true);


    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==exit) System.exit(0);
        if(e.getSource()==potw){
            if(panelImie.getText().equals("")){
                System.out.println("3");
                JOptionPane.showMessageDialog(null, "Podaj imie", "UWAGA", JOptionPane.WARNING_MESSAGE);
            }
            if(panelNazw.getText().equals("")){
                System.out.println("2");
                JOptionPane.showMessageDialog(null, "Podaj nazwisko", "UWAGA", JOptionPane.WARNING_MESSAGE);
            }
            if (!I.isSelected() && !II.isSelected() && !III.isSelected() && !IV.isSelected()) {
                System.out.println("1");
                JOptionPane.showMessageDialog(null, "Zaznacz klase", "UWAGA", JOptionPane.WARNING_MESSAGE);
            }


            if(!panelImie.getText().equals("") && !panelNazw.getText().equals("") &&(I.isSelected() || II.isSelected() || III.isSelected() || IV.isSelected())) {
                imie=panelImie.getText();
                nazwisko=panelNazw.getText();

                Ark2 ark2 = new Ark2(imie, nazwisko);
                this.setVisible(false);
            }
        }


        }

    }
