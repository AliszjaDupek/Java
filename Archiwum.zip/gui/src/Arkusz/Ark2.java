package Arkusz;

import javax.swing.*;
import java.awt.*;

public class Ark2 extends JFrame{
    JLabel napis;
    JLabel label;

    public Ark2(String imie, String nazwisko){
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(300, 300);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(0x6E8FD1));
        label= new JLabel();
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.TOP);
        label.setOpaque(true);
        label.setBounds(100,100,100,100);
        ImageIcon icon = new ImageIcon(new ImageIcon("src/p.png").getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT));

        napis = new JLabel("Cześć "+imie+" "+nazwisko);
        napis.setBounds(75,5,400,100);
        napis.setFont(new Font("Times New Roman",Font.PLAIN,20));


        label.setIcon(icon);

        this.setIconImage(icon.getImage());
        this.add(napis);
        this.add(label);
        this.setVisible(true);


    }

}
