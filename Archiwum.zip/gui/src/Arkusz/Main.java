package Arkusz;

public class Main {
    public static void main(String[] args){
        Arkusz arkusz = new Arkusz();
    }
}
