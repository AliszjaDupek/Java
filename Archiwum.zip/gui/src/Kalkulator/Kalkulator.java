package Kalkulator;

import javax.management.StringValueExp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kalkulator extends JFrame implements ActionListener {

    JTextField okno;
    JButton[] numeryButtons;
    JButton[] funkcjaButtons;
    JButton addButton;
    JButton subButton;
    JButton mulButton;
    JButton divButton;
    JButton delButton;
    JButton clrButton;
    JButton eqlButton;
    JButton decButton;
    JButton plmnButton;
    JPanel panel;
    double liczba1;
    double liczba2;
    double wynik;
    String operator = "";

    public Kalkulator() {
        funkcjaButtons = new JButton[9];
        numeryButtons = new JButton[10];

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(420, 550);
        this.setLayout(null);
        this.getContentPane().setBackground(new Color(0x6E8FD1));

        okno = new JTextField();
        okno.setBounds(50, 25, 300, 50);
        okno.setEditable(false);

        plmnButton = new JButton("+-");
        addButton = new JButton("+");
        subButton = new JButton("-");
        mulButton = new JButton("*");
        divButton = new JButton("/");
        clrButton = new JButton("\uD83D\uDDD1");
        delButton = new JButton("⌫");
        eqlButton = new JButton("=");
        decButton = new JButton(".");

        funkcjaButtons[0] = addButton;
        funkcjaButtons[1] = subButton;
        funkcjaButtons[2] = mulButton;
        funkcjaButtons[3] = divButton;
        funkcjaButtons[4] = clrButton;
        funkcjaButtons[5] = delButton;
        funkcjaButtons[6] = eqlButton;
        funkcjaButtons[7] = decButton;
        funkcjaButtons[8] = plmnButton;

        for (int i = 0; i < 9; i++) {
            funkcjaButtons[i].addActionListener(this);
            funkcjaButtons[i].setFont(new Font("ITALIC", Font.BOLD, 20));
            funkcjaButtons[i].setBackground(new Color(0x416CC4));
            funkcjaButtons[i].setOpaque(true);
            funkcjaButtons[i].setBorderPainted(false);
        }
        plmnButton.setFont(new Font("ITALIC", Font.PLAIN, 4));
        for (int i = 0; i < 10; i++) {
            numeryButtons[i] = new JButton(String.valueOf(i));
            numeryButtons[i].addActionListener(this);
            numeryButtons[i].setFont(new Font("ITALIC", Font.BOLD, 30));

        }

        delButton.setBounds(50, 430, 110, 50);
        clrButton.setBounds(170, 430, 110, 50);
        plmnButton.setBounds(300, 430, 50, 50);

        panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4, 4, 10, 10));
        panel.setBackground(new Color(0x93A7D1));


        panel.add(numeryButtons[7]);
        panel.add(numeryButtons[8]);
        panel.add(numeryButtons[9]);
        panel.add(funkcjaButtons[0]);
        panel.add(numeryButtons[4]);
        panel.add(numeryButtons[5]);
        panel.add(numeryButtons[6]);
        panel.add(funkcjaButtons[1]);
        panel.add(numeryButtons[1]);
        panel.add(numeryButtons[2]);
        panel.add(numeryButtons[3]);
        panel.add(funkcjaButtons[3]);
        panel.add(funkcjaButtons[7]);
        panel.add(numeryButtons[0]);
        panel.add(funkcjaButtons[6]);
        panel.add(funkcjaButtons[2]);
        this.add(panel);


        this.add(delButton);
        this.add(clrButton);
        this.add(plmnButton);
        this.add(okno);

        this.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < 10; i++) {
            if (e.getSource() == numeryButtons[i]) {
                okno.setText(okno.getText().concat(String.valueOf(i)));

            }
        }

        if (e.getSource() == decButton) {
            if (!(okno.getText().contains("."))) {
                okno.setText(okno.getText().concat("."));
            }
        }

        if (e.getSource() == addButton) {
            liczba1 = Double.parseDouble(okno.getText());
            operator = "+";
            okno.setText("");
        }

        if (e.getSource() == subButton) {
            liczba1 = Double.parseDouble(okno.getText());
            operator = "-";
            okno.setText("");
        }
        if (e.getSource() == mulButton) {
            liczba1 = Double.parseDouble(okno.getText());
            operator = "*";
            okno.setText("");
        }
        if (e.getSource() == divButton) {
            liczba1 = Double.parseDouble(okno.getText());
            operator = "/";
            okno.setText("");
        }
        if (e.getSource() == eqlButton) {
            if (operator.equals("")) {
                JOptionPane.showMessageDialog(null, "Musisz wybrać operację", "UWAGA", JOptionPane.WARNING_MESSAGE);
            } else {
                liczba2 = Double.parseDouble(okno.getText());
                if (operator.equals("+")) {
                    wynik = liczba1 + liczba2;
                }
                if (operator.equals("-")) {
                    wynik = liczba1 - liczba2;
                }
                if (operator.equals("*")) {
                    wynik = liczba1 * liczba2;
                }
                if (operator.equals("/")) {
                    wynik = liczba1 / liczba2;
                }
                okno.setText(String.valueOf(wynik));
            }
        }
        String napis = null;

        if (e.getSource() == delButton) {
            if (okno.getText().length() == 1 || okno.getText().length() == 0) {
                okno.setText("");
            } else {
                for (int i = 0; i < okno.getText().length() - 1; i++) {
                    napis += okno.getText().charAt(i);
                }
                if (napis.endsWith(".")) {
                    napis = napis.substring(0, napis.length() - 1);
                }
                if (napis.endsWith("-")) {
                    napis = napis.substring(0, napis.length() - 1);
                }
                okno.setText(napis);
                if (okno.getText().contains("null")) {
                    okno.setText(okno.getText().replace("null", ""));
                }
            }
        }
        if (e.getSource() == clrButton) {
            okno.setText("");
            liczba1 = 0;
            liczba2 = 0;
            operator = "";
            wynik = 0;
        }

        if (e.getSource() == plmnButton) {
            if (okno.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Brak liczby", "UWAGA", JOptionPane.WARNING_MESSAGE);
            }
            else{
                if (String.valueOf(okno.getText().charAt(0)).equals("-")) {
                    okno.setText(okno.getText().replace("-", ""));
                } else {
                    okno.setText(okno.getText().replace(String.valueOf(okno.getText().charAt(0)), "-" + okno.getText().charAt(0)));
                }
            }
        }
    }
}

