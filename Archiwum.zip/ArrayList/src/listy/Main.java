package listy;

public class Main {
    public static void main(String[] args) {
//        MyArrayList<Integer> lista = new MyArrayList<>();
//        lista.add(1);
//        lista.add(2);
//        lista.add(3);
//        lista.add(4);
//        lista.add(1,3);
//        System.out.println(lista.toString());
////        lista.remove(lista.indexOf(3));
//        System.out.println(lista.remove(3));
//        System.out.println(lista.toString());
//        System.out.println(lista.size());
//        System.out.println(lista.contains(9));
//        lista.clear();
//        System.out.println(lista.isEmpty());
//        System.out.println(lista.size());
        LinkedList<Integer> lista = new LinkedList<>();
        lista.add(1);
        lista.add(1,2);
        System.out.println(lista.toString());
        System.out.println(lista.remove(0));
        System.out.println(lista.remove(lista.indexOf(0)));
        System.out.println(lista.toString());

    }
}
