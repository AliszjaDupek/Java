package listy;

public class LinkedList<E> extends MyArrayList{
    private class Element{
        @Override
        public String toString() {
            return "Element{" +
                    "value=" + value +
                    ", next=" + next +
                    '}';
        }

        private E value;
        private Element next;
        Element(E data){
            this.value=data;
        }
        public E getValue() {
            return value;
        }
        public Element getNext() {
            return next;
        }
        public void setValue(E value) {
            this.value = value;
        }
        public void setNext(Element next) {
            this.next = next;
        }
    }
    Element head = null;

    public LinkedList(){}
    public boolean isEmpty(){
        return head==null;
    }
    public void clear(){
        head=null;
    }
    public int size(){
        int size = 0;
        Element act = head;
        while(act!=null){
            size++;
            act = act.getNext();
        }
        return size;
    }

    private Element getElement(int index){
        Element act = head;
        while (index>0 && act!=null){
            index--;
            act=act.getNext();
        }
        return act;
    }

    public boolean add(Object e) {
        E ele = (E) e;
        Element element = new Element(ele);
        if (head == null) {
            head = element;
            return true;
        }
        Element tail = head;
        while (tail.getNext() != null) {
            tail = tail.getNext();
        }
        tail.setNext(element);
        return true;
    }
    public boolean add(int index, Object e){
        E elem = (E) e;
        if(index<0) return false;
        Element element = new Element(elem);
        if(index==0){
            element.setNext(head);
            head=element;
            return true;
        }
        Element actualElem = getElement(index-1);
        if(actualElem==null){
            return false;
        }
        element.setNext(actualElem.getNext());
        actualElem.setNext(element);
        return true;
    }
    public E remove(int index){
        if(head==null){
            return null;
        }
        if(index==0){
            E newVal = head.getValue();
            head = head.getNext();
            return newVal;
        }

        Element actElem = getElement(index-1);
        if(actElem==null || actElem.getNext()==null){
            return null;
        }

        E retValue = actElem.getNext().getValue();
        actElem.setNext(actElem.getNext().getNext());
        return retValue;
    }

    @Override
    public String toString() {
        return "LinkedList{" +
                "head=" + head.toString() +
                '}';
    }
}
