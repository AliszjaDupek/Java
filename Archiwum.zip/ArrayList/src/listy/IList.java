package listy;

public interface IList<E> {
    boolean add(E e); //dodanie elementu na koniec listy
    boolean add(int index, E e); //dodanie elementu w podanej pozycji
    void clear(); //usuniecie wszystkich elementow
    boolean contains(E e); //sprawdza czy lista posiada liczbe
    E get(int index); //podaje liczba o podanym indexie
    E set(int index, E e);
    int indexOf(E e);
    boolean isEmpty();
    E remove(int index);
    boolean remove(E e);
    int size();

}
