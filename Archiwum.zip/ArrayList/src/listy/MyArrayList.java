package listy;

import java.util.Arrays;

public class MyArrayList<E> implements IList<E> {
    private static final int DEFAULT_SIZE = 10;
    private E[] array;
    private int inicialCapacity;
    private int size;

    @SuppressWarnings("unchecked")
    public MyArrayList(int capacity) {
        if (capacity <= 0) {
            capacity = DEFAULT_SIZE;
        }
        array = (E[]) (new Object[capacity]);
        inicialCapacity = capacity;
        size = 0;
    }

    public MyArrayList() {
        this(DEFAULT_SIZE);
    }

    @SuppressWarnings("unchecked")
    private void ensureCapasity(int capacity) {
        if (array.length < capacity) {
            E[] copy = (E[])(new Object[capacity + capacity / 2]);
            System.arraycopy(array, 0, copy, 0, size);
            array = copy;
        }

    }


    private void checkBounds(int index) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
    }

    @Override
    public boolean add(E e) {
        ensureCapasity(size + 1);
        array[size] = e;
        size++;
        return true;
    }

    @Override
    public boolean add(int index, E e) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        ensureCapasity(size+1);
        if (index != size) {
            System.arraycopy(array, index, array, index + 1, size - index);
        }
        array[index] = e;
        size++;
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void clear() {
        array = (E[]) (new Object[inicialCapacity]);
        size = 0;
    }

    @Override
    public boolean contains(E e) {
        return indexOf(e) != -1;
    }

    @Override
    public E get(int index) {
        checkBounds(index);
        return array[index];
    }

    @SuppressWarnings("unchecked")
    @Override
    public E set(int index, E e) {
        checkBounds(index);
        E resultValue = array[index];
        array[index] = e;
        return resultValue;
    }

    @Override
    public int indexOf(E e) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (array[i].equals(e)) {
                index = i;
            }
        }
        return index;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public E remove(int index) {
        checkBounds(index);
        E returnValue = array[index];
        int copyFrom = index + 1;
        if (copyFrom < size) {
            System.arraycopy(array, copyFrom, array, index, size - index);
        }
        --size;
        return returnValue;
    }

    @Override
    public boolean remove(E e) {
        int myIndex = indexOf(e);
        if (myIndex != -1 && myIndex < size) {
            remove(myIndex);
            return true;
        }
        return false;
    }


    @Override
    public int size() {
        return size;
    }

    @Override
    public String toString() {
        return "MyArrayList{" +
                "array=" + Arrays.toString(array) +
                ", inicialCapacity=" + inicialCapacity +
                ", size=" + size +
                '}';
    }
}
