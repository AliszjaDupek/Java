package stosKolejka;

import java.util.Arrays;

public class Stack <T> implements IStack<T>{
    private static final int DEFAULT_SIZE = 5;
    T [] array;
    int topIndex;

    @SuppressWarnings("unchecked")
    public  Stack(int inicialSize){
        array = (T[])(new Object[inicialSize]);
        topIndex=0;
    }
    public Stack(){
        this(DEFAULT_SIZE);
    }



    @Override
    public boolean isEmpty() {
        return topIndex==0;
    }

    @Override
    public boolean isFull() {
        return topIndex==array.length;
    }

    @Override
    public T pop() {
        if(isEmpty()){
            return null;
        }else{
            return array[--topIndex];
        }
    }

    @Override
    public void push(T elem) {
        if(isFull()){
            System.out.println("Stos jest pełny");
        } else{
            array[topIndex++] = elem;
        }

    }

    @Override
    public int size() {
        return topIndex;
    }

    @Override
    public T top() {
        if(isEmpty()){
            return null;
        }else{
            return array[topIndex-1];
        }
    }

    @Override
    public String toString() {
        return "Stack{" +
                "array=" + Arrays.toString(array) +
                ", topIndex=" + topIndex +
                '}';
    }
}
