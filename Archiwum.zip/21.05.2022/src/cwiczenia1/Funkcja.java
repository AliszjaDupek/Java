package cwiczenia1;

public class Funkcja {

    public static int dodaj(int a, int b){
        return a+b;
    }

    public static int odejmij(int a,int b){
        return a-b;
    }

    public static int pomnoz(int a, int b){
        return a*b;
    }

    public static int podziel(int a, int b){
        return a/b;
    }

    public static double dodaj(double a, double b){
        return a+b;
    }

    public static void main(String[] args){
        System.out.println(dodaj(1,2));
        System.out.println(dodaj(1.56,1.87));
        System.out.println(odejmij(5,6));
        System.out.println(pomnoz(8,9));
        System.out.println(podziel(90,45));
    }

}
