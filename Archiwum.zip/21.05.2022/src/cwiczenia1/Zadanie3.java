package cwiczenia1;

import java.util.Scanner;

public class Zadanie3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.println("Podaj 1 bok");
        int a = sc.nextInt();
        System.out.println("Podaj 2 bok");
        int b = sc.nextInt();
        System.out.println("Podaj 3 bok");
        int c = sc.nextInt();

        if(a==c || a==b || b==c){
            System.out.println("Można zbudować trójkąt równoramienny");
        }

    }

}
