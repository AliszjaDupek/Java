package cwiczenia1;

public class Zad7 {

    public static boolean spr(int[] a, int b){
        int licznik = 0;
        for ( int i : a){
            if(i == b){
                licznik = licznik + 1;

            }
        }
        if (licznik>1){
            return true;
        }
        else{
            return false;
        }
    }
    public static void main(String[] args){
        int[] tab = new int[3];
        tab[0] = 1;
        tab[1] = 2;
        tab[2] = 1;
        System.out.println(spr(tab,1));
    }
}
