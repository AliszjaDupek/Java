package cwiczenia1;

public class Zad3 {

    public static boolean pf(String a, int b){
        if (a.length()==b){
            return true;
        }
        else{
            return false;
        }
    }
    public static void main(String[] args){
        System.out.println(pf("napis",5 ));


    }
}
