package cwiczenia1;

public class Zad1 {
    public static boolean trj(int a, int b, int c){
        if (a * a + b * b == c * c || c * c + a * a == b * b || b * b + c * c == a * a) {
            return true;
        } else{
            return false;
        }
    }


    public static void main(String[] args){
        System.out.println(trj(3,4,5));
    }
}
