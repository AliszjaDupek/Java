package cwiczenia1;

import java.util.Random;

public class Macierze {

    public static int[][] utwMacierz(int wiersze, int kolumny){
        int[][] m = new int[wiersze][kolumny];
        Random rn = new Random();
        for ( int i = 0; i < wiersze; i++) {
            for (int y = 0; y < kolumny; y++) {
                m[i][y] = rn.nextInt(10);
            }
        }
        return m;
    }

    public static void wyswietl(int[][] macierz){
        for ( int[] wiersz : macierz){
            for (int liczba : wiersz){
                System.out.print(liczba+" ");
            }
            System.out.println();
        }
    }

    public static void wyswietlMacierz(int[][] macierz){
        for (int wiersz = 0; wiersz < macierz.length; wiersz++){
            for (int liczba = 0; liczba < macierz[wiersz].length; liczba++){
                System.out.print(macierz[wiersz][liczba]+" ");
            }
            System.out.println();
        }
    }

    public static int suma(int[][] macierz){
        int suma = 0;
        for(int wiersz = 0; wiersz < macierz.length; wiersz++) {
            for (int liczba = 0; liczba < macierz[wiersz].length; liczba++) {
                suma=suma+macierz[wiersz][liczba];
            }
        }
        return suma;
    }

    public static int[][] dodajMacierze(int[][] macierz1, int[][] macierz2) {

        if (macierz1.length != macierz2.length){
            System.out.println("Liczba wierszy sie nie zgadza");
            return null;
        }
        int[][] macierz_suma = new int[macierz1.length][];
        for(int w = 0; w < macierz1.length; w++){
            if (macierz1[w].length!=macierz2[w].length){
                System.out.println("Liczba kolumn się nie zgadza");
                return null;

            }
            int[] wiersz = new int[macierz1[w].length];
            for(int k = 0; k < macierz1[w].length; k++){
                wiersz[k]=macierz1[w][k]+macierz2[w][k];
                }
                macierz_suma[w] = wiersz;

            }
            return macierz_suma;
        }
    public static int[][] mnozenie(int[][] macierz, int x){
        for(int w = 0; w < macierz.length; w++){
            for(int k = 0; k < macierz[w].length; k++){
                macierz[w][k]=macierz[w][k]*x;

            }
        }
        return macierz;
    }



    public static void main(String[] args){
        int[][] macierz = utwMacierz(3,4);
        wyswietlMacierz(macierz);
        System.out.println(suma(macierz));
        wyswietlMacierz(mnozenie(utwMacierz(3,4),2));



    }

}
