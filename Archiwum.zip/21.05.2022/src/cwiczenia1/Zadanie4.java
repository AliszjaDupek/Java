package cwiczenia1;

import java.util.Scanner;

public class Zadanie4 {

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.println("Podaj liczbę");
        int x = sc.nextInt();

        if (x%6==0){
            System.out.println("Liczba jest podzielna przez 2 i 3");
        }


    }
}
