package cwiczenia1;

public class Zad2 {
    public static boolean prk(int a, int b, int c, int d){
        if (a==b && c==d || a==c && b==d || a==d && b==c){
            return true;
        }
        else{
            return false;
        }

    }


    public static void main(String[] args){
        System.out.println(prk(1,4,4,1));



    }
}
