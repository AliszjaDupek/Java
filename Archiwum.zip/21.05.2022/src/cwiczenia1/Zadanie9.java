package cwiczenia1;

public class Zadanie9 {
    public static void main(String[] args){
        for( int i = 101; i < 201; i++){
            System.out.println(i);
        }


    }

}
