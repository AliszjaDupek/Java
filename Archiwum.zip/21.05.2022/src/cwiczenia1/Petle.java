package cwiczenia1;

import java.util.Scanner;

public class Petle {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        // int a = 0;
        //  while (a <= 50){
        //    System.out.println("Podaj liczbę");
        //    a = sc.nextInt();
        //   if (a>50) {
        //       System.out.println("Liczba jest większa niż 50");
        //       break;
        //   }

            for (int i=2; i < 21; i=i+2){
                System.out.println(i);
            }



        }

    }

