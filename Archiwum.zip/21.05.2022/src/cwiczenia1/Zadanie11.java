package cwiczenia1;

import java.util.Scanner;

public class Zadanie11 {

    public static void main(String[] args){
        long iloczyn = 1;

        for ( int i = 51; i < 61; i++){
            iloczyn = iloczyn * i;
        }


        System.out.println(iloczyn);

    }
}
