package cwiczenia1;

public class Zad4 {

    public static String[] tablica(String a, String b){
        String[] tab = new String[2];
        tab[0] = a;
        tab[1] = b;
        return tab;
    }

    public static void wtab(String[] a){
        for (String i : a){
            System.out.println(i);
        }

    }
    public static void main(String[] args){
        wtab(tablica("napis","tab"));

    }


}
