package cwiczenia1;

public class Zad6 {
    public static int dodaj(int[] a, int b){
        int suma = 0;
        for ( int i : a){
            if(i < b){
                suma = suma + i;
            }
        }
        return suma;
    }

    public static void main(String[] args){
        int[] tab = new int[4];
        tab[0] = 1;
        tab[1] = 2;
        tab[2] = 3;
        tab[3] = 1;
        System.out.println(dodaj(tab, 3));

    }




}
