package cwiczenia1;

public class Zad5 {
    public static int dodaj(int[] a) {
        int suma = 0;
        for (int i : a) {
            if (i > 5) {
                suma = suma + i;
            }
        }
        return suma;
    }
        public static void main (String[]args){
            int[] tab = new int[3];
            tab[0] = 1;
            tab[1] = 6;
            tab[2] = 8;
            System.out.println(dodaj(tab));
        }

}