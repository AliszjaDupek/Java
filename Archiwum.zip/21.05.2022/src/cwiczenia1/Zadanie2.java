package cwiczenia1;

import java.util.Scanner;

public class Zadanie2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Podaj 1 bok");
        int a = sc.nextInt();
        System.out.println("Podaj 2 bok");
        int b = sc.nextInt();
        System.out.println("Podaj 3 bok");
        int c = sc.nextInt();
        System.out.println("Podaj 4 bok");
        int d = sc.nextInt();

        if(a==b && b==c && c==d){
            System.out.println("Można stworzyć kwadrat");
        }
    }

}
