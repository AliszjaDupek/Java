package cwiczenia1;

public class Zadanie10 {
    public static void main(String[] args){
        int suma = 0;

        for(int i = 51; i < 101; i++){
            suma = suma + i;


        }
        System.out.println(suma);

    }
}
