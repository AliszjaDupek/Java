package cwiczenia1;

import java.util.Scanner;

public class Zadanie1 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Podaj pierwszy bok");
        int a = sc.nextInt();
        System.out.println("Podaj drugi bok");
        int b = sc.nextInt();
        System.out.println("Podaj trzeci bok");
        int c = sc.nextInt();

        if (a==b && a==c){
            System.out.println("Trójkąt jest równoboczny");

        }
        else{
            System.out.println("Trójkąt nie jest równoboczny");
        }

    }

}
