public class Prostopadloscian extends Bryla{

    int a;
    int b;

    public Prostopadloscian(){
        nazwa="Bazowy";
        a=1;
        b=1;
        h=1;
    }
    public Prostopadloscian(String nazwa, int a, int b, int h){
        this.nazwa=nazwa;
        this.a=a;
        this.b=b;
        this.h=h;
    }


    @Override
    public int objetosc() {
        return a*b*h;
    }

    @Override
    public int pole() {
        return (2*a*b)+(2*a*h)+(2*b*h);
    }

    @Override
    public String toString() {
        return "Prostopadłościan: "+nazwa+"[a= "+a+" ,b= "+b+"]";
    }
    public boolean jestSzescianem(){
        if(a==b && b==h){
            return true;
        }
    return false;
    }

}
