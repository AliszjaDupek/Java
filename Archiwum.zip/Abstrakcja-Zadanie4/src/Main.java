public class Main {
    public static void main(String[] args) {
        Prostopadloscian p = new Prostopadloscian();
        Walec w = new Walec();
        System.out.println(w.toString());
        System.out.println(w.objetosc());
        System.out.println(w.pole());
        System.out.println(p.toString());
        System.out.println(p.objetosc());
        System.out.println(p.pole());
        System.out.println(p.jestSzescianem());
    }
}