public abstract class Bryla {
    String nazwa;
    int h;
    public Bryla(){
        nazwa="";
        h=0;
    }
    public Bryla(String nazwa, int h){
        this.nazwa=nazwa;
        this.h=h;
    }

    @Override
    public String toString() {
        return "Bryła o nazwie : "+nazwa;
    }
    public abstract int objetosc();
    public abstract int pole();
}
