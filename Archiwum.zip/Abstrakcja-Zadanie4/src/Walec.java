public class Walec extends Bryla{

    int r;
    public Walec(){
        nazwa="Bazowy";
        r=1;
        h=1;
    }
    public Walec(String nazwa, int h, int r){
        this.nazwa=nazwa;
        this.h=h;
        this.r=r;
    }

    @Override
    public int objetosc() {
        return (int) (r*r*3.14*h);
    }

    @Override
    public int pole() {
        return (int)((2*3.14*r*h)+(2*3.14*r*r));
    }

    @Override
    public String toString() {
        return "Walec: "+nazwa+"[r= "+r+", h= "+h+"]";
    }
}
