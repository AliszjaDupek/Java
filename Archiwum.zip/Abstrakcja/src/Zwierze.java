public abstract class Zwierze {
    protected String terytorium;
    protected String pozywienie;
    protected int glod;

    public Zwierze(){
        terytorium = "Afryka";
        glod=10;
        pozywienie="Trawa";
    }
    public Zwierze(String terytorium, String pozywienie, int glod){
        this.terytorium=terytorium;
        this.pozywienie=pozywienie;
        this.glod=glod;
    }

    public void jedz(){
        System.out.println("Jem");
    }

    public void wedruj(){
        System.out.println("Wedruje");
    }

    public abstract void przedstawSie();
}
