public abstract class Psowate extends Zwierze{
    @Override
    public void wedruj() {
        System.out.println("Biegne");
    }

    @Override
    public void przedstawSie() {
        System.out.println("Jestem psem");
    }
}
