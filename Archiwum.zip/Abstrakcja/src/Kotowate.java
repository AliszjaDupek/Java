public abstract class Kotowate extends Zwierze{
    @Override
    public void wedruj() {
        System.out.println("Skradam sie");
    }

    @Override
    public void przedstawSie() {
        System.out.println("jestem jakims kotem");
    }
}
