public class Hipopotam extends Zwierze{
    @Override
    public void wedruj() {
        System.out.println("Glosno plywam");
    }
    @Override
    public void jedz() {
        System.out.println("Jem zielenine");
    }

    @Override
    public void przedstawSie() {
        System.out.println("Jestem hipopotamem");
    }
}
