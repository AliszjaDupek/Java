public class Main {
    public static void main(String[] args) {
        Pies p = new Pies();
        Kot k = new Kot();
        //Zwierze z = new Zwierze();

        Zwierze[] zwierze = new Zwierze[3];
        zwierze[0] = p;
        zwierze[1]=k;

        jakaKlasa(p);
        jakaKlasa(k);

        System.out.println(p.terytorium);
        System.out.println(zmianiaTerytorium(p).terytorium);

        p.bawSie();
        k.badzMilutki();
    }
    public static void jakaKlasa(Zwierze zwierze){
        System.out.println(zwierze.getClass());
    }
    public static Zwierze zmianiaTerytorium(Zwierze zwierze){
        zwierze.terytorium="Europa";
        return zwierze;
    }
}