public class Pies extends Psowate implements ZwierzakDomowy{
    @Override
    public void jedz() {
        System.out.println("Jem karme");
    }

    @Override
    public void przedstawSie() {
        System.out.println("Jestem pieskiem");
    }

    @Override
    public void badzMilutki() {
        System.out.println("Jestem milutki");
    }

    @Override
    public void bawSie() {
        System.out.println("Rzuc pilke");
    }
}
