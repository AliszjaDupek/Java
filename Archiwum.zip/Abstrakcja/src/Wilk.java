public class Wilk extends Psowate{
    @Override
    public void jedz() {
        System.out.println("Poluje");
    }

    @Override
    public void przedstawSie() {
        System.out.println("Jestem wilkiem");
    }
}
