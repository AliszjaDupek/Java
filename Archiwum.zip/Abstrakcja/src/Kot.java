public class Kot extends Kotowate implements ZwierzakDomowy{
    @Override
    public void jedz() {
        System.out.println("Jem myszki");
    }

    @Override
    public void badzMilutki() {
        System.out.println("Jestem milutki");
    }

    @Override
    public void bawSie() {
        System.out.println("Miau");
    }
}
