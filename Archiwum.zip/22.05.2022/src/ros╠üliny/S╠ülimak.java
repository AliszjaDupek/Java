package rośliny;

import java.util.Random;

public class Ślimak {

    Random rn = new Random();
    protected boolean czy_skorupa;
    protected String kolor;


    //CONSTRUCTORY

    public Ślimak() {
        czy_skorupa = true;
        kolor = "brązowy";
    }


    public Ślimak(boolean czy_skorupa, String kolor) {
        this.czy_skorupa = czy_skorupa;
        this.kolor = kolor;

    }

    //GETTERY


    public String getKolor() {
        return kolor;
    }

    public boolean isCzy_skorupa() {
        return czy_skorupa;
    }


    //SETTERY


    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public void setCzy_skorupa(boolean czy_skorupa) {
        this.czy_skorupa = czy_skorupa;
    }

    public void zjedzRoslineZOgrodu(Ogród ogród) {
        Random rn = new Random();
        int miejsceWOgrodzie;
        do {
            miejsceWOgrodzie = rn.nextInt(ogród.getKwiatki_w_ogrodzie().length);
        } while (ogród.getKwiatki_w_ogrodzie()[miejsceWOgrodzie] == null);

        ogród.getKwiatki_w_ogrodzie()[miejsceWOgrodzie] = null;
        System.out.println("Ślimak zjadł kwiatka");
    }
    
}
