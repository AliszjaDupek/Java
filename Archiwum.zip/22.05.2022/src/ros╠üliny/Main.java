package rośliny;

public class Main {

    public static void main(String[] args){

        Roślina roślina1 = new Roślina();
        Roślina roślina2 = new Roślina("biały", "skrzydłokwiat", 100, true );
        Roślina roślina3 = new Roślina();
        Drzewo drzewo1 = new Drzewo();
        Drzewo drzewo2 = new Drzewo(false, 100, 300, "dąb", "zielony", true, 50);


        Roślina[] rosliny = {roślina1, roślina2, roślina3, drzewo1, drzewo2};

        if (rosliny[3] instanceof Drzewo) {
            ((Drzewo)rosliny[3]).zawiesHustawke();
        }

        Ogród ogród = new Ogród(rosliny, 10, 4, "Alicja");
        Ogród ogród1 = new Ogród();

        System.out.println(ogród);
        System.out.println(ogród1);

        ogród.dodajKwiatka(new Roślina("fioletowy", "irys", 30, true), 3);
        ogród.dodajKwiatka(new Roślina(), 0);

        ogród.wykopGrządki(2);
        ogród.dodajKwiatka(new Roślina("niebieski", "irys", 30, true), 3);


    }







}
