package rośliny;

public class Drzewo extends Roślina{
    protected boolean czy_iglaste;
    protected int wiek;
    protected int obwód_cm;


//CONSTRUCTORY
    public Drzewo(){
        super();
        this.gatunek = "świerk";
        czy_iglaste = true;
        wiek = 40;
        obwód_cm = 92;

    }

    public Drzewo(boolean czy_iglaste, int wiek, int obwód_cm, String gatunek, String kolor, boolean czy_ma_kwiatki, int okres_wegetacji){
        this.czy_iglaste=czy_iglaste;
        this.wiek=wiek;
        this.obwód_cm=obwód_cm;
        this.gatunek=gatunek;
        this.kolor=kolor;
        this.czy_ma_kwiatki=czy_ma_kwiatki;
        this.okres_wegetacji=okres_wegetacji;

    }

    @Override
    public String toString() {
        if (czy_iglaste)
            return "Drzewo iglaste "+ super.toString();
        else
            return "Drzewo liściaste "+ super.toString();
    }

    public void zawiesHustawke(){
        System.out.println("Możesz się pohuśtać");

    }
}
