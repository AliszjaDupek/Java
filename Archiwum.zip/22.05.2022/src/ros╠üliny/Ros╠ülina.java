package rośliny;

public class Roślina {

    protected String kolor;
    protected String gatunek;
    protected int okres_wegetacji;
    protected boolean czy_ma_kwiatki;

//CONSTRUCTORY

//domyślny
    public Roślina(){
        kolor="zielony";
        gatunek="kaktus";
        okres_wegetacji=365;
        czy_ma_kwiatki=true;
    }
//parametryczny
    public Roślina(String kolor, String gatunek, int okres_wegetacji, boolean czy_ma_kwiatki){
        this.kolor=kolor;
        this.gatunek=gatunek;
        this.okres_wegetacji=okres_wegetacji;
        this.czy_ma_kwiatki=czy_ma_kwiatki;

    }





//GETTERY---------------------------------------------------------------------------
    public String getGatunek() {
        return gatunek;
    }

    public boolean isCzyMaKwiatki() {
        return czy_ma_kwiatki;
    }

    public String getKolor() {
        return kolor;
    }

    public int getOkresWegetacji() {
        return okres_wegetacji;
    }
//SETTERY--------------------------------------------------------------------------
    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public void isCzyMaKwiatki(boolean czy_ma_kwiatki){
        this.czy_ma_kwiatki = czy_ma_kwiatki;
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public void setOkres_wegetacji(int okres_wegetacji) {
        this.okres_wegetacji = okres_wegetacji;
    }

    @Override
    public String toString(){
        return kolor + " " + gatunek;
    }

    @Override
    public boolean equals(Object roślina2) {
        if (roślina2 instanceof Roślina)
            return gatunek.equals(((Roślina)roślina2).gatunek);
        else
            return false;
    }


    public void podlej(){
        System.out.println("Roślina podlana");
    }

    public void powachaj(){
        if (czy_ma_kwiatki)
            System.out.println("O, jak ładnie pachnie");
        else
            System.out.println("Nie pachnie :(");



    }
}
