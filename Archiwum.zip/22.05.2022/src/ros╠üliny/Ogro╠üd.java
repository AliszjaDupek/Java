package rośliny;

public class Ogród {

    private Roślina[] kwiatki_w_ogrodzie;
    private int szerokosc_ogrodu;
    private int dlugosc_ogrodu;
    private String wlasciciel;

    //konstruktory

    public Ogród() {
        kwiatki_w_ogrodzie = new Roślina[5];
        szerokosc_ogrodu = 5;
        dlugosc_ogrodu = 4;
        wlasciciel = "Alicja Dudek";
    }

    public Ogród(Roślina[] kwiatki_w_ogrodzie, int szerokosc_ogrodu, int dlugosc_ogrodu, String wlasciciel) {
        this.wlasciciel = wlasciciel;
        this.dlugosc_ogrodu = dlugosc_ogrodu;
        this.szerokosc_ogrodu = szerokosc_ogrodu;
        this.kwiatki_w_ogrodzie = kwiatki_w_ogrodzie;
    }


    public Ogród(int szerokosc_ogrodu, int dlugosc_ogrodu, String wlasciciel) {
        this.wlasciciel = wlasciciel;
        this.szerokosc_ogrodu = szerokosc_ogrodu;
        this.dlugosc_ogrodu = dlugosc_ogrodu;
        this.kwiatki_w_ogrodzie = new Roślina[5];
    }


    //GETTERY


    public int getDlugosc_ogrodu() {
        return dlugosc_ogrodu;

    }

    public Roślina[] getKwiatki_w_ogrodzie() {
        return kwiatki_w_ogrodzie;
    }

    public String getWlasciciel() {
        return wlasciciel;
    }

    public int getSzerokosc_ogrodu() {
        return szerokosc_ogrodu;
    }

    //SETTERY


    public void setDlugosc_ogrodu(int dlugosc_ogrodu) {
        this.dlugosc_ogrodu = dlugosc_ogrodu;
    }

    public void setKwiatki_w_ogrodzie(Roślina[] kwiatki_w_ogrodzie) {
        this.kwiatki_w_ogrodzie = kwiatki_w_ogrodzie;
    }

    public void setSzerokosc_ogrodu(int szerokosc_ogrodu) {
        this.szerokosc_ogrodu = szerokosc_ogrodu;
    }

    public void setWlasciciel(String wlasciciel) {
        this.wlasciciel = wlasciciel;
    }

    @Override
    public String toString() {
        String napis = "Ogród: " + wlasciciel;
        napis += "\nRozmiar: " + oblicz_powierzchnie() + "m^2";
        if (kwiatki_w_ogrodzie == null || kwiatki_w_ogrodzie.length == 0) {
            napis += "\nBrak kwiatków w ogrodzie";
        } else {
            napis += "\nRośliny:\n";
            napis += getRoslinyWOgrodzie();
        }
        return napis;

    }

    private int oblicz_powierzchnie() {
        return szerokosc_ogrodu * dlugosc_ogrodu;
    }

    private String getRoslinyWOgrodzie() {
        StringBuilder rosliny = new StringBuilder();

        for (Roślina r : kwiatki_w_ogrodzie) {
            if (r != null)
                rosliny.append(r).append("\n");
        }

        return rosliny.toString();
    }

    public void dodajKwiatka(Roślina roślina, int miejsce){
        if (miejsce < kwiatki_w_ogrodzie.length) {
            if (kwiatki_w_ogrodzie[miejsce] != null)
                System.out.println("Wyrzucono "+kwiatki_w_ogrodzie[miejsce]);
            kwiatki_w_ogrodzie[miejsce] = roślina;
            System.out.println("Posadzono "+roślina.toString());
        }
        else

            System.out.println("Masz za mały ogród :/");

    }

    public void wykopGrządki(int wykopywane ){
        Roślina[] nowekwiatki = new Roślina[kwiatki_w_ogrodzie.length+wykopywane];
        for (int k = 0; k < kwiatki_w_ogrodzie.length; k++){
            nowekwiatki[k] = kwiatki_w_ogrodzie[k];

        }
        kwiatki_w_ogrodzie=nowekwiatki;
    }

}


